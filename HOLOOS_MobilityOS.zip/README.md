# HOLOOS MobilityOS

Prototipo PWA basado en la interfaz de movilidad mostrada.

## Funciones
- Mapa interactivo
- GPS del dispositivo
- Vehículos cercanos
- Selección de destino
- Asignación básica del vehículo por proximidad
- Viaje / Comida / Entrega
- Seguridad
- Service Worker / PWA

## Ejecución
Servir la carpeta mediante HTTP/HTTPS. Para GPS y Service Worker se recomienda HTTPS (o localhost).

El mapa usa OpenStreetMap mediante Leaflet.
