const state = {
  location: null,
  destination: null,
  service: "ride",
  vehicles: [],
  activeTrip: null
};

const map = L.map("map", { zoomControl:false }).setView([9.935, -84.08], 13);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  maxZoom: 19,
  attribution: "&copy; OpenStreetMap contributors"
}).addTo(map);

const vehicleLayer = L.layerGroup().addTo(map);
let userMarker = null;

const vehicles = [
  {id:"V-101",lat:9.939,lng:-84.074,rating:4.9},
  {id:"V-102",lat:9.928,lng:-84.087,rating:4.8},
  {id:"V-103",lat:9.944,lng:-84.091,rating:4.7},
  {id:"V-104",lat:9.917,lng:-84.068,rating:4.9},
  {id:"V-105",lat:9.951,lng:-84.081,rating:4.8}
];

function renderVehicles(){
  vehicleLayer.clearLayers();
  vehicles.forEach(v=>{
    const marker=L.marker([v.lat,v.lng],{
      icon:L.divIcon({
        className:"",
        html:'<div style="font-size:30px">🚗</div>',
        iconSize:[34,34],
        iconAnchor:[17,17]
      })
    });
    marker.bindPopup(`<b>${v.id}</b><br>⭐ ${v.rating}`);
    marker.addTo(vehicleLayer);
  });
}
renderVehicles();

function setStatus(text){
  document.getElementById("status").textContent = "HOLOOS • " + text;
}

async function getLocation(){
  if(!navigator.geolocation){
    setStatus("GPS no disponible");
    return;
  }
  navigator.geolocation.getCurrentPosition(pos=>{
    state.location={
      lat:pos.coords.latitude,
      lng:pos.coords.longitude,
      accuracy:pos.coords.accuracy
    };
    if(userMarker) userMarker.remove();
    userMarker=L.circleMarker([state.location.lat,state.location.lng],{
      radius:9
    }).addTo(map).bindPopup("Tu ubicación");
    map.setView([state.location.lat,state.location.lng],15);
    setStatus(`GPS ±${Math.round(state.location.accuracy)} m`);
  },()=>{
    setStatus("No se pudo obtener GPS");
  },{enableHighAccuracy:true,timeout:10000,maximumAge:5000});
}

function distance(a,b){
  const R=6371000, p=Math.PI/180;
  const x=Math.sin((b.lat-a.lat)*p/2)**2+
    Math.cos(a.lat*p)*Math.cos(b.lat*p)*Math.sin((b.lng-a.lng)*p/2)**2;
  return 2*R*Math.atan2(Math.sqrt(x),Math.sqrt(1-x));
}

function assignBestVehicle(){
  const origin=state.location || {lat:9.935,lng:-84.08};
  return [...vehicles].sort((a,b)=>
    distance(origin,a)-distance(origin,b)
  )[0];
}

function requestTrip(){
  const input=document.getElementById("destination");
  state.destination=input.value.trim();
  if(!state.destination){
    setStatus("Escribe un destino");
    input.focus();
    return;
  }
  const driver=assignBestVehicle();
  state.activeTrip={
    id:crypto.randomUUID(),
    origin:state.location,
    destination:state.destination,
    driver,
    status:"DRIVER_ASSIGNED",
    createdAt:Date.now()
  };
  setStatus(`Conductor ${driver.id} asignado • ⭐${driver.rating}`);
  document.getElementById("panelText").textContent=
    `Viaje a ${state.destination}. Vehículo ${driver.id} asignado por IA.`;
}

function selectService(service){
  state.service=service;
  document.querySelectorAll(".service").forEach(b=>
    b.classList.toggle("active",b.dataset.service===service)
  );
  const title={ride:"Viaje",food:"Comida",delivery:"Entrega"}[service];
  const text={
    ride:"Vehículos cercanos y solicitud inteligente.",
    food:"Descubre restaurantes y crea tu pedido.",
    delivery:"Envía o recibe productos con seguimiento."
  }[service];
  document.getElementById("panelTitle").textContent=title;
  document.getElementById("panelText").textContent=text;
  document.getElementById("requestBtn").textContent=
    service==="ride"?"Solicitar viaje":
    service==="food"?"Crear pedido":"Solicitar entrega";
}

document.querySelectorAll(".service").forEach(b=>
  b.addEventListener("click",()=>selectService(b.dataset.service))
);

document.querySelectorAll("[data-destination]").forEach(b=>
  b.addEventListener("click",()=>{
    document.getElementById("destination").value=b.dataset.destination;
  })
);

document.getElementById("requestBtn").addEventListener("click",()=>{
  if(state.service==="ride") requestTrip();
  else setStatus(state.service==="food"?"Pedido preparado":"Entrega preparada");
});

document.getElementById("locateBtn").addEventListener("click",getLocation);

document.getElementById("safetyBtn").addEventListener("click",()=>{
  const active=!!state.activeTrip;
  setStatus(active?"Seguridad activa • viaje protegido":"Seguridad disponible");
  alert(active?"🛡️ Seguridad activada para el viaje.":"🛡️ Seguridad lista.");
});

document.getElementById("menuBtn").addEventListener("click",()=>{
  alert("HOLOOS MobilityOS\\n\\nViaje • Comida • Entrega\\nIA • GPS • Seguridad • Tracking");
});

document.getElementById("playBtn").addEventListener("click",()=>{
  setStatus("Modo juego / experiencias disponible");
});

if("serviceWorker" in navigator){
  navigator.serviceWorker.register("service-worker.js").catch(()=>{});
}
getLocation();
