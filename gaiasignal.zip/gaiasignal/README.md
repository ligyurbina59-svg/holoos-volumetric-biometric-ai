# GAIA SIGNAL

**Sistema nervioso planetario distribuido**

Esto **no es una aplicación**.

Es un protocolo abierto de coordinación regenerativa + una implementación de referencia de nodo local.

## Qué es diferente

| Apps tradicionales | Gaia Signal |
|--------------------|-------------|
| Se instalan | No requiere instalación |
| Tienen dueño | Sin dueño |
| Compiten por atención | No busca atención |
| Centralizan datos | Los datos viven en los nodos |
| Miden usuarios | Miden regeneración real |
| Optimizan engagement | Optimizan impacto ecológico verificable |

## Cómo usarlo ahora mismo

1. Abre el archivo `nodes/index.html` en cualquier navegador (incluso sin internet después de la primera carga).
2. Emite señales de tipo VITAL, ACT, PROOF, NEED, OFFER o SYNC.
3. Las señales se guardan solo en tu navegador (localStorage). No hay servidor.

Ese es el punto: el protocolo puede vivir en cualquier lugar.

## Estructura

```
gaiasignal/
├── docs/
│   └── PROTOCOL.md          ← El protocolo completo
├── nodes/
│   └── index.html           ← Nodo de referencia (funcional)
├── assets/
│   └── earth.png
└── README.md
```

## Próximos pasos posibles (si quieres construir más)

- Transporte por SMS / Meshtastic / LoRa
- Firmas criptográficas ligeras
- Verificación de PROOF con evidencias (fotos + hashes + NDVI)
- Mapa colectivo de señales (opcional y federado)
- Nodos físicos (QR + NFC en el territorio)

## Principio rector

> La mejor tecnología para el planeta es aquella que se vuelve invisible  
> porque ya forma parte de la forma en que los humanos y los ecosistemas  
> se coordinan para regenerar.

No más apps.  
Sistemas nerviosos.
