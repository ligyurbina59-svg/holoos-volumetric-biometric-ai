# GAIA SIGNAL
## Protocolo de Coordinación Regenerativa Planetaria

**Versión 0.1 — 13 de septiembre de 2026**  
**Estado:** Implementación de referencia activa  
**Naturaleza:** Protocolo abierto, sin dueño, sin app store, sin extractivismo de atención.

---

### 1. Por qué esto no es una app

Las apps:
- Compiten por atención
- Centralizan datos
- Requieren instalación y permisos
- Optimizan engagement
- Tienen dueño

Gaia Signal:
- No compite por atención
- Los datos pertenecen a los nodos
- Funciona sin instalación (navegador, SMS, radio, señal física)
- Optimiza **impacto regenerativo verificable**
- No tiene dueño ni empresa detrás

Es un **sistema nervioso distribuido** para el planeta.

---

### 2. Principios fundacionales

1. **Regeneración > Extracción**  
   Toda señal debe poder vincularse a un efecto positivo medible en un ecosistema real.

2. **Sin intermediario propietario**  
   Cualquiera puede emitir, recibir y verificar señales. No hay servidor central obligatorio.

3. **Mínima fricción**  
   Un nodo puede ser una persona con un teléfono básico, un sensor LoRa, un árbol etiquetado, una comunidad o un satélite.

4. **Prueba de impacto, no prueba de trabajo**  
   El valor de una señal se mide por el cambio real que produce (agua recuperada, biodiversidad aumentada, carbono secuestrado, suelo regenerado…).

5. **Interoperable por diseño**  
   Compatible con web, SMS, radio de baja potencia, códigos QR físicos, balizas, etc.

---

### 3. Tipos de Señal (Signal Types)

| Código | Nombre              | Descripción                                      | Ejemplo |
|--------|---------------------|--------------------------------------------------|-------|
| `VITAL`  | Señal Vital         | Estado de salud de un ecosistema local           | "Río X: oxígeno disuelto 4.2 mg/L – crítico" |
| `ACT`    | Acción Regenerativa | Propuesta o ejecución de una intervención        | "Reforestación 2.4 ha – zona norte – iniciada" |
| `PROOF`  | Prueba de Impacto   | Evidencia verificable de cambio positivo         | "Cobertura vegetal +18% en 90 días – fotos + NDVI" |
| `NEED`   | Necesidad           | Recurso o conocimiento requerido                 | "Se necesitan 400 esquejes de mangle rojo" |
| `OFFER`  | Oferta              | Recurso o capacidad disponible                   | "Disponibles 3 días de trabajo + herramientas" |
| `SYNC`   | Sincronización      | Coordinación temporal entre nodos                | "Ventana de siembra óptima: 12-18 oct" |

---

### 4. Estructura mínima de una Señal

```json
{
  "gaia": "1.0",
  "type": "VITAL | ACT | PROOF | NEED | OFFER | SYNC",
  "node": "identificador-local-o-público",
  "location": {
    "lat": 0.0,
    "lon": 0.0,
    "precision": "exact | area | region"
  },
  "ecosystem": "river | forest | soil | ocean | urban | wetland | ...",
  "payload": { ... },
  "timestamp": "ISO-8601",
  "proof": null | { "method": "...", "data": "..." },
  "signature": "opcional – firma criptográfica del nodo"
}
```

---

### 5. Cómo funciona sin “app”

- **Navegador**: Cualquiera abre un nodo local (archivo HTML o página estática).
- **SMS / WhatsApp / Signal**: Se pueden enviar señales en texto estructurado.
- **Radio / LoRa / Meshtastic**: Ideal para zonas sin internet.
- **Físico**: Códigos QR o balizas NFC en el territorio que emiten o reciben señales.
- **Sensores**: Dispositivos IoT emiten señales `VITAL` automáticamente.

El protocolo es el lenguaje común.  
La interfaz es cualquiera.

---

### 6. Métrica de éxito

No se mide en usuarios activos diarios.  
Se mide en:

- Hectáreas en proceso de regeneración
- Toneladas de carbono adicionalmente secuestrado
- Especies cuya tendencia poblacional mejoró
- Comunidades que recuperaron soberanía hídrica o alimentaria
- Reducción de degradación neta

---

### 7. Gobernanza

No hay fundación central ni empresa.  
El protocolo evoluciona por consenso de nodos activos y evidencia de impacto.  
Cualquiera puede proponer mejoras. Las que demuestran mayor regeneración se adoptan.

---

**Gaia Signal no quiere ser usada.**  
Quiere volverse invisible: la capa de coordinación que permite que la inteligencia humana y la inteligencia de los ecosistemas trabajen juntas.

Fin del documento de protocolo v0.1
