# HOLOOS MobilityOS

**Software libre / Open Source** — Licencia MIT

Prototipo de Progressive Web App (PWA) de movilidad inteligente.

## Características

- Mapa interactivo con OpenStreetMap + Leaflet
- GPS del dispositivo
- Vehículos cercanos simulados
- Selección de destino
- Asignación básica de vehículo por proximidad
- Modos: Viaje / Comida / Entrega
- Botón de Seguridad
- Service Worker (funcionamiento offline básico)
- Instalable como PWA (Android / iOS / Desktop)

## Requisitos

- Navegador moderno con soporte de Service Workers y Geolocation
- Servidor HTTP/HTTPS (recomendado `localhost` o HTTPS real para GPS y PWA)

## Instalación / Ejecución rápida

```bash
# Clonar o descargar
git clone https://github.com/tu-usuario/holoos-mobilityos.git
cd holoos-mobilityos

# Servir localmente
npx serve .
# o
python -m http.server 8080
```

Abre `http://localhost:8080` (o el puerto que uses).

## Generar APK

1. Publica el proyecto en cualquier hosting con HTTPS (GitHub Pages, Netlify, Vercel…).
2. Entra en [PWABuilder](https://www.pwabuilder.com)
3. Pega la URL de tu PWA → Package for stores → Android.

## Estructura del proyecto

```
holoos-mobilityos/
├── index.html
├── app.js
├── styles.css
├── manifest.json
├── service-worker.js
├── icon-192.png
├── icon-512.png
├── icon-192-maskable.png
├── icon-512-maskable.png
├── LICENSE
└── README.md
```

## Licencia

Este software es **libre y de código abierto** bajo la licencia **MIT**.

Puedes usarlo, modificarlo, redistribuirlo y usarlo en proyectos comerciales siempre que mantengas el aviso de copyright y la licencia.

Ver el archivo [LICENSE](LICENSE) para el texto completo.

## Contribuciones

¡Las contribuciones son bienvenidas! Abre un issue o un pull request.

---

Hecho con ❤️ como software libre.
