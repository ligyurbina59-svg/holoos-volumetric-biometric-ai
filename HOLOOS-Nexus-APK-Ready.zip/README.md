# HOLOOS Nexus

App unificada:
- 🎮 Gamepad (WebSocket → TV/PC)
- 🍔 Food (cliente)
- 🛵 Driver
- 📱 Social (feed demo)
- 🤖 IA (asistente local demo)
- 🌍 Geo

## APK
Publica en HTTPS → https://www.pwabuilder.com → Package → Android
