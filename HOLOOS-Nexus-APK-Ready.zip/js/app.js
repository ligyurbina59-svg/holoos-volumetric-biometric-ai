// HOLOOS Nexus — Gamepad + Food + IA + Social

let ws = null;

const FOOD_HTML = `
  <h3>🍔 HOLOOS Food</h3>
  <p>Pide comida a domicilio (demo).</p>
  <div class="menu-row"><strong>Burger House</strong><br><span style="color:#8b9bb4;font-size:12px">⭐ 4.8 · 25-35 min</span></div>
  <div class="menu-row"><strong>Pizza Roma</strong><br><span style="color:#8b9bb4;font-size:12px">⭐ 4.6 · 30-40 min</span></div>
  <div class="menu-row"><strong>Sushi Nikkei</strong><br><span style="color:#8b9bb4;font-size:12px">⭐ 4.9 · 35-45 min</span></div>
  <button class="action-btn" style="margin-top:12px" onclick="alert('Pedido demo enviado')">Ver menú completo</button>
`;

const DRIVER_HTML = `
  <h3>🛵 Food Driver</h3>
  <p>Modo repartidor (demo).</p>
  <div class="menu-row">Estado: <strong style="color:#22c55e">Listo para conectar</strong></div>
  <div class="menu-row">Pedidos hoy: 0 · Ganancias: $0</div>
  <p style="font-size:12px;margin-top:10px">Acepta términos del Driver en la app Food Driver dedicada.</p>
`;

const SOCIAL_HTML = `
  <h3>📱 Social</h3>
  <div class="feed-item"><strong>@holoos</strong><p style="margin:6px 0 0;color:#8b9bb4">Nexus unifica Gamepad, Food, IA y red social.</p></div>
  <div class="feed-item"><strong>@driver_01</strong><p style="margin:6px 0 0;color:#8b9bb4">En ruta · pedido #2041</p></div>
  <div class="feed-item"><strong>@geo</strong><p style="margin:6px 0 0;color:#8b9bb4">Acceso verificado · región permitida</p></div>
  <p style="font-size:12px;color:#8b9bb4;margin-top:8px">Feed demo. Conecta backend (chats/posts) cuando PostgreSQL esté listo.</p>
`;

const AI_HTML = `
  <h3>🤖 Asistente IA</h3>
  <div class="ai-box" id="ai-out">Pregúntame sobre Nexus, comida, gamepad o la app.</div>
  <div class="ai-input">
    <input type="text" id="ai-in" placeholder="Escribe un mensaje..." />
    <button id="ai-send">Enviar</button>
  </div>
`;

const GEO_HTML = `
  <h3>🌍 Geo Status</h3>
  <div class="menu-row">País (demo): <strong>MX</strong> · Permitido ✅</div>
  <p style="font-size:12px;color:#8b9bb4">Conecta tu API /api/geo-status para datos reales.</p>
`;

function openPanel(title, html) {
  document.getElementById('panel-title').textContent = title;
  document.getElementById('panel-body').innerHTML = html;
  document.getElementById('panel').classList.remove('hidden');
  const send = document.getElementById('ai-send');
  if (send) {
    send.addEventListener('click', runAI);
    document.getElementById('ai-in').addEventListener('keydown', e => { if (e.key === 'Enter') runAI(); });
  }
}

function runAI() {
  const input = document.getElementById('ai-in');
  const out = document.getElementById('ai-out');
  if (!input || !out) return;
  const q = input.value.trim();
  if (!q) return;
  const replies = [
    'Nexus combina Gamepad, Food, IA y Social en una PWA.',
    'Para la TV: conecta el WebSocket del Gamepad a tu receptor.',
    'Food y Driver son módulos demo listos para backend.',
    'Puedes generar el APK con PWABuilder tras publicar en HTTPS.'
  ];
  out.innerHTML = `<strong>Tú:</strong> ${q}<br><br><strong>IA:</strong> ${replies[Math.floor(Math.random()*replies.length)]}`;
  input.value = '';
}

function showHome() {
  document.getElementById('home-view').classList.remove('hidden');
  document.getElementById('gamepad-view').classList.add('hidden');
}

function showGamepad() {
  document.getElementById('home-view').classList.add('hidden');
  document.getElementById('gamepad-view').classList.remove('hidden');
}

// Cards
document.querySelectorAll('.card').forEach(btn => {
  btn.addEventListener('click', () => {
    const m = btn.dataset.mod;
    if (m === 'gamepad') {
      showGamepad();
      document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
      document.querySelector('.nav-item[data-tab="gamepad"]').classList.add('active');
      return;
    }
    if (m === 'food') openPanel('Food', FOOD_HTML);
    if (m === 'driver') openPanel('Driver', DRIVER_HTML);
    if (m === 'social') openPanel('Social', SOCIAL_HTML);
    if (m === 'ai') openPanel('IA', AI_HTML);
    if (m === 'geo') openPanel('Geo', GEO_HTML);
  });
});

document.getElementById('panel-close').addEventListener('click', () => {
  document.getElementById('panel').classList.add('hidden');
});

document.getElementById('btn-ai').addEventListener('click', () => openPanel('IA', AI_HTML));

// Nav
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
    item.classList.add('active');
    const t = item.dataset.tab;
    if (t === 'home') showHome();
    if (t === 'gamepad') showGamepad();
    if (t === 'food') openPanel('Food', FOOD_HTML);
    if (t === 'social') openPanel('Social', SOCIAL_HTML);
    if (t === 'ai') openPanel('IA', AI_HTML);
  });
});

// Gamepad buttons
function sendKey(key, type) {
  const payload = JSON.stringify({ type: type || 'button', key, t: Date.now() });
  if (ws && ws.readyState === 1) ws.send(payload);
  console.log(payload);
}

document.querySelectorAll('.gp-btn').forEach(btn => {
  const key = btn.dataset.key;
  const down = e => { e.preventDefault(); btn.classList.add('pressed'); sendKey(key, 'down'); };
  const up = e => { e.preventDefault(); btn.classList.remove('pressed'); sendKey(key, 'up'); };
  btn.addEventListener('touchstart', down, { passive: false });
  btn.addEventListener('touchend', up, { passive: false });
  btn.addEventListener('mousedown', down);
  btn.addEventListener('mouseup', up);
  btn.addEventListener('mouseleave', up);
});

document.getElementById('gp-connect').addEventListener('click', () => {
  const url = document.getElementById('ws-url').value.trim() || 'ws://127.0.0.1:3001';
  const st = document.getElementById('gp-status');
  try {
    if (ws) ws.close();
    ws = new WebSocket(url);
    st.textContent = 'Conectando...';
    ws.onopen = () => { st.textContent = 'Conectado · ' + url; st.classList.add('on'); };
    ws.onclose = () => { st.textContent = 'Desconectado'; st.classList.remove('on'); };
    ws.onerror = () => { st.textContent = 'Error de conexión'; st.classList.remove('on'); };
  } catch (err) {
    st.textContent = 'URL inválida';
  }
});

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('./sw.js').catch(() => {});
}
