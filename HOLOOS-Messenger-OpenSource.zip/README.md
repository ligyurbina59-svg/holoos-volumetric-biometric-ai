# HOLOOS Messenger

**Software libre / Open Source** — Licencia MIT

Progressive Web App de mensajería con presencia holográfica conceptual.

> “HOLO no devuelve vidas. Preserva memorias.”

## Características

- Chats locales (almacenamiento en el navegador)
- Interfaz de mensajería moderna
- Pestaña de presencia holográfica (conceptual)
- Memoria / Contactos / Verdad
- Service Worker (offline)
- Instalable como PWA
- Diseño oscuro orientado a móvil

## Requisitos

- Navegador moderno
- Servidor HTTP/HTTPS

## Ejecución

```bash
npx serve .
# o
python -m http.server 8080
```

## Generar APK

Usa [PWABuilder](https://www.pwabuilder.com) con la URL pública de tu instancia.

## Estructura

```
holoos-messenger/
├── index.html
├── css/
│   ├── app.css
│   └── messenger.css
├── js/
│   ├── app.js
│   ├── messenger.js
│   ├── storage.js
│   ├── holoos-engine.js
│   ├── holoscene.js
│   └── volumetric.js
├── icons/
│   ├── icon-192.png
│   ├── icon-512.png
│   ├── icon-192-maskable.png
│   └── icon-512-maskable.png
├── manifest.json
├── sw.js
├── LICENSE
└── README.md
```

## Licencia

**MIT License** — Software libre y open source.

Puedes usarlo, modificarlo y redistribuirlo libremente (incluyendo uso comercial) manteniendo el aviso de copyright.

Ver [LICENSE](LICENSE).

## Contribuciones

Pull requests e issues son bienvenidos.

---

Software libre · Hecho para preservar memorias.
