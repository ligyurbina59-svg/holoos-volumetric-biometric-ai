# Contribuir a HOLOOS

¡Gracias por tu interés en contribuir a este software libre!

## Cómo contribuir

1. Haz un fork del repositorio
2. Crea una rama (`git checkout -b feature/nueva-funcionalidad`)
3. Realiza tus cambios
4. Asegúrate de que el código sea claro y esté comentado cuando sea necesario
5. Envía un Pull Request

## Código de conducta

- Sé respetuoso
- Prioriza la claridad y la mantenibilidad del código
- Documenta cambios importantes

## Licencia de las contribuciones

Al contribuir, aceptas que tus aportes se publiquen bajo la misma licencia MIT del proyecto.
