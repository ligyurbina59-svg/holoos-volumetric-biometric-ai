/**
 * XN-Memory · HOLO Volumetric
 * App principal + renderizado + HoloScene
 */

const $ = (id) => document.getElementById(id);

const state = {
  tab: 'home',
  data: null,
  playing: false,
  currentVoice: null,
  holoAnim: null,
  holoPerson: null
};

// ----------------------------------------------------------
// Init
// ----------------------------------------------------------
async function init() {
  try {
    state.data = await Storage.load();
    await updateStorageStatus();
    bindEvents();
    render();
  } catch (e) {
    console.error('Init error', e);
    toast('Error al cargar datos');
  }
}

async function updateStorageStatus() {
  try {
    const info = await Storage.info();
    const el = $('storage-status');
    if (el) {
      el.textContent = `IDB · ${info.memories} mem · ${(info.bytes / 1024).toFixed(1)} KB`;
    }
  } catch (e) {
    console.error(e);
  }
}

function bindEvents() {
  document.querySelectorAll('.tab').forEach(t => {
    t.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
      t.classList.add('active');
      state.tab = t.dataset.tab;
      stopHolo();
      render();
    });
  });

  $('btn-add').onclick = () => openModal();
  $('m-cancel').onclick = () => closeModal();
  $('m-save').onclick = saveNewMemory;
  $('p-close').onclick = stopPlayer;
  $('p-play').onclick = togglePlayer;
  $('h-close').onclick = stopHolo;
  $('h-voice').onclick = () => {
    if (state.holoPerson) {
      // Simula voz real de la primera evidencia de audio si existe
      toast('Reproduciendo voz real (simulado)');
    }
  };
}

// ----------------------------------------------------------
// Toast
// ----------------------------------------------------------
function toast(msg) {
  const el = $('toast');
  el.textContent = msg;
  el.classList.remove('hidden');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.add('hidden'), 2600);
}

// ----------------------------------------------------------
// Modal
// ----------------------------------------------------------
function openModal() {
  $('m-title').value = '';
  $('m-person').value = '';
  $('m-date').value = '';
  $('m-note').value = '';
  $('m-auth').value = 'ORIGINAL';
  $('modal').classList.remove('hidden');
}

function closeModal() {
  $('modal').classList.add('hidden');
}

async function saveNewMemory() {
  const title = $('m-title').value.trim();
  const personName = $('m-person').value.trim();
  const date = $('m-date').value;
  const note = $('m-note').value.trim();
  const authenticity = $('m-auth').value;

  if (!title) {
    toast('Escribe un título');
    return;
  }

  try {
    // Buscar o crear persona
    let person = state.data.people.find(p => p.name.toLowerCase() === personName.toLowerCase());
    if (!person && personName) {
      person = await Storage.addPerson({
        name: personName,
        avatar: '👤',
        relation: 'Familiar',
        years: '',
        quote: ''
      });
    }

    const memory = {
      title,
      personId: person ? person.id : null,
      domain: 'PERSONAL',
      subtype: 'EXPERIENCIA',
      authenticity,
      dateStart: date || null,
      dateEnd: null,
      note,
      evidence: note ? [{ id: 'txt_' + Date.now(), type: 'TEXT', authenticity, label: 'Nota' }] : [],
      timeline: date ? [{ id: 'ev_' + Date.now(), date, label: title, authenticity }] : [],
      status: 'ACTIVE'
    };

    await Storage.addMemory(memory);
    state.data = await Storage.load();
    await updateStorageStatus();
    closeModal();
    toast('Memoria guardada · ' + authenticityLabel(authenticity));
    state.tab = 'memories';
    document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
    document.querySelector('[data-tab="memories"]').classList.add('active');
    render();
  } catch (e) {
    console.error(e);
    toast('Error al guardar');
  }
}

// ----------------------------------------------------------
// Player (simulado)
// ----------------------------------------------------------
function playVoice(person, label = 'Voz real') {
  state.currentVoice = { person, label };
  state.playing = true;
  $('player').classList.remove('hidden');
  $('p-av').textContent = person.avatar || '👤';
  $('p-name').textContent = person.name;
  $('p-title').textContent = label + ' · voz real';
  $('p-play').textContent = '⏸';
  const bar = document.querySelector('.player-bar');
  bar.classList.remove('playing');
  void bar.offsetWidth;
  bar.classList.add('playing');
  clearTimeout(playVoice._t);
  playVoice._t = setTimeout(stopPlayer, 8500);
  toast('Memoria real · reproduciendo');
}

function stopPlayer() {
  state.playing = false;
  state.currentVoice = null;
  $('p-play').textContent = '▶';
  document.querySelector('.player-bar')?.classList.remove('playing');
  $('player').classList.add('hidden');
}

function togglePlayer() {
  if (state.playing) stopPlayer();
  else if (state.currentVoice) playVoice(state.currentVoice.person, state.currentVoice.label);
}

// ----------------------------------------------------------
// HoloScene (pipeline biométrico → volumétrico)
// ----------------------------------------------------------
let presenceSession = null;

function openHolo(personId) {
  const person = state.data.people.find(p => p.id === personId);
  if (!person) return;

  state.holoPerson = person;
  $('holo-ui').classList.remove('hidden');
  $('h-name').textContent = person.name;
  $('h-quote').textContent = person.quote ? `“${person.quote}”` : '“…”';

  const mems = state.data.memories.filter(m => m.personId === personId && m.status !== 'DELETED');
  const auths = [...new Set(mems.map(m => m.authenticity))];
  $('h-auth').innerHTML = auths.map(a =>
    `<span class="badge ${a}">${authenticityLabel(a)}</span>`
  ).join('') || '<span class="badge UNKNOWN">⚪ Sin evidencia</span>';

  // API de alto nivel (como el snippet Kotlin)
  // 1. Setup
  const canvas = $('holo-canvas');
  if (!presenceSession) {
    presenceSession = new HoloosPresenceSession(canvas);
  }

  // 2-5. Context + process + visualize + render
  presenceSession.setPerson(person, auths);
  presenceSession.setContext({
    memory: mems[0] || null,
    personId: person.id,
    authLevels: auths
  });
  presenceSession.start();
}

function stopHolo() {
  if (presenceSession) {
    // 6. Analytics / provenance (opcional)
    const report = presenceSession.getProvenanceReport();
    if (report && !report.empty) {
      console.log('[HOLO Provenance]', report);
    }
    presenceSession.stop();
  }
  state.holoPerson = null;
  $('holo-ui').classList.add('hidden');
}

// ----------------------------------------------------------
// Helpers
// ----------------------------------------------------------
function authenticityLabel(code) {
  const map = {
    ORIGINAL: '🟢 ORIGINAL',
    RECONSTRUCTED: '🔵 RECONSTRUIDO',
    INFERRED: '🟣 IA / INFERIDO',
    GENERATED: '🟠 GENERADO',
    UNKNOWN: '⚪ DESCONOCIDO'
  };
  return map[code] || code;
}

function formatDate(iso) {
  if (!iso) return '—';
  try {
    const d = new Date(iso);
    return d.toLocaleDateString('es', { year: 'numeric', month: 'short', day: 'numeric' });
  } catch {
    return iso;
  }
}

// ----------------------------------------------------------
// Render tabs
// ----------------------------------------------------------
function render() {
  const content = $('content');
  switch (state.tab) {
    case 'home': content.innerHTML = renderHome(); break;
    case 'memories': content.innerHTML = renderMemories(); break;
    case 'holo': content.innerHTML = renderHoloList(); break;
    case 'family': content.innerHTML = renderFamily(); break;
    case 'auth': content.innerHTML = renderAuth(); break;
    default: content.innerHTML = renderHome();
  }
}

function renderHome() {
  const mems = state.data.memories.filter(m => m.status !== 'DELETED');
  const people = state.data.people;

  return `
    <div class="card">
      <h3>◈ XN-Memory</h3>
      <p>HOLO no devuelve vidas.<br>Preserva memorias, misión, visión y propósito.</p>
      <div class="meta">
        <span>${mems.length} memorias</span>
        <span>${people.length} personas</span>
        <span>Almacenamiento local</span>
      </div>
    </div>

    <div class="card">
      <h3>Principio de verdad</h3>
      <div class="auth-legend">
        <div class="auth-row"><div class="auth-dot ORIGINAL"></div> 🟢 ORIGINAL — evidencia real</div>
        <div class="auth-row"><div class="auth-dot RECONSTRUCTED"></div> 🔵 RECONSTRUIDO — completado con base</div>
        <div class="auth-row"><div class="auth-dot INFERRED"></div> 🟣 IA / INFERIDO — interpretación</div>
        <div class="auth-row"><div class="auth-dot GENERATED"></div> 🟠 GENERADO — sintético</div>
        <div class="auth-row"><div class="auth-dot UNKNOWN"></div> ⚪ DESCONOCIDO — sin verificar</div>
      </div>
    </div>

    ${mems.slice(0, 3).map(m => memoryCard(m)).join('') || '<div class="empty"><div class="big">🧠</div>Aún no hay memorias</div>'}
  `;
}

function memoryCard(m) {
  const person = state.data.people.find(p => p.id === m.personId);
  return `
    <div class="card" onclick="viewMemory('${m.id}')">
      <h3>
        <span class="badge ${m.authenticity}">${authenticityLabel(m.authenticity)}</span>
        ${m.title}
      </h3>
      <p>${m.note || 'Sin descripción'}</p>
      <div class="meta">
        <span>${person ? person.avatar + ' ' + person.name : 'Sin persona'}</span>
        <span>${formatDate(m.dateStart)}</span>
        <span>${m.status}</span>
      </div>
    </div>
  `;
}

function renderMemories() {
  const mems = state.data.memories.filter(m => m.status !== 'DELETED');
  if (!mems.length) {
    return `<div class="empty"><div class="big">🧠</div><p>No hay memorias todavía.<br>Pulsa ＋ para añadir una.</p></div>`;
  }
  return mems.map(m => memoryCard(m)).join('');
}

function viewMemory(id) {
  const m = state.data.memories.find(x => x.id === id);
  if (!m) return;
  const person = state.data.people.find(p => p.id === m.personId);

  $('content').innerHTML = `
    <div class="card">
      <h3>${m.title}</h3>
      <span class="badge ${m.authenticity}">${authenticityLabel(m.authenticity)}</span>
      <p style="margin-top:10px">${m.note || ''}</p>
      <div class="meta">
        <span>${person ? person.avatar + ' ' + person.name : '—'}</span>
        <span>${formatDate(m.dateStart)}${m.dateEnd ? ' → ' + formatDate(m.dateEnd) : ''}</span>
      </div>
    </div>

    <div class="card">
      <h3>Timeline</h3>
      ${(m.timeline || []).map(ev => `
        <div style="padding:8px 0;border-bottom:1px solid rgba(148,163,184,0.08)">
          <strong style="font-size:13px">${ev.label}</strong>
          <div class="meta">
            <span>${ev.date}</span>
            <span class="badge ${ev.authenticity}">${authenticityLabel(ev.authenticity)}</span>
          </div>
        </div>
      `).join('') || '<p style="color:var(--muted);font-size:13px">Sin eventos</p>'}
    </div>

    <div class="card">
      <h3>Evidencia</h3>
      ${(m.evidence || []).map(e => `
        <div style="padding:6px 0;font-size:13px">
          ${e.type} · ${e.label || e.id}
          <span class="badge ${e.authenticity}">${authenticityLabel(e.authenticity)}</span>
        </div>
      `).join('') || '<p style="color:var(--muted);font-size:13px">Sin evidencia</p>'}
    </div>

    <div class="btn-row">
      <button class="btn secondary" onclick="render()">← Volver</button>
      ${person ? `<button class="btn" onclick="openHolo('${person.id}')">✦ Presencia</button>` : ''}
    </div>
  `;
}

function renderHoloList() {
  const people = state.data.people;
  if (!people.length) {
    return `<div class="empty"><div class="big">✦</div><p>No hay personas para proyectar presencia.</p></div>`;
  }
  return `
    <div class="card">
      <h3>Presencia visual</h3>
      <p>HOLO genera una presencia a partir de las memorias. <strong>No recrea a la persona.</strong></p>
    </div>
    ${people.map(p => `
      <div class="card mem-item" onclick="openHolo('${p.id}')">
        <div class="av">${p.avatar}</div>
        <div class="info">
          <strong>${p.name}</strong>
          <span>${p.relation || ''} ${p.years ? '· ' + p.years : ''}</span>
        </div>
      </div>
    `).join('')}
  `;
}

function renderFamily() {
  const people = state.data.people;
  return `
    <div class="card">
      <h3>♡ Familia</h3>
      <p>Personas vinculadas a tus memorias.</p>
    </div>
    ${people.map(p => {
      const count = state.data.memories.filter(m => m.personId === p.id && m.status !== 'DELETED').length;
      return `
        <div class="card mem-item">
          <div class="av">${p.avatar}</div>
          <div class="info">
            <strong>${p.name}</strong>
            <span>${p.relation || 'Familiar'} · ${count} memoria${count !== 1 ? 's' : ''}</span>
            ${p.quote ? `<p style="margin-top:6px;font-size:12px;font-style:italic;color:var(--muted)">“${p.quote}”</p>` : ''}
          </div>
        </div>
      `;
    }).join('') || '<div class="empty">Sin personas todavía</div>'}
  `;
}

function renderAuth() {
  return `
    <div class="card">
      <h3>◎ Sistema de autenticidad</h3>
      <p>HOLO nunca confunde lo real con lo inferido o generado.</p>
    </div>

    <div class="card">
      <div class="auth-legend">
        <div class="auth-row"><div class="auth-dot ORIGINAL"></div>
          <div><strong>🟢 ORIGINAL</strong><br><span style="color:var(--muted);font-size:12px">Evidencia/fuente original conservada (foto, audio, vídeo).</span></div>
        </div>
        <div class="auth-row"><div class="auth-dot RECONSTRUCTED"></div>
          <div><strong>🔵 RECONSTRUIDO</strong><br><span style="color:var(--muted);font-size:12px">Elemento completado a partir de información disponible.</span></div>
        </div>
        <div class="auth-row"><div class="auth-dot INFERRED"></div>
          <div><strong>🟣 IA / INFERIDO</strong><br><span style="color:var(--muted);font-size:12px">Interpretación generada por el sistema. NO es hecho confirmado.</span></div>
        </div>
        <div class="auth-row"><div class="auth-dot GENERATED"></div>
          <div><strong>🟠 GENERADO</strong><br><span style="color:var(--muted);font-size:12px">Contenido sintético creado por IA (voz, imagen, diálogo…).</span></div>
        </div>
        <div class="auth-row"><div class="auth-dot UNKNOWN"></div>
          <div><strong>⚪ DESCONOCIDO</strong><br><span style="color:var(--muted);font-size:12px">Procedencia o veracidad aún no establecida.</span></div>
        </div>
      </div>
    </div>

    <div class="card">
      <h3>Reglas de no-promoción</h3>
      <p style="font-size:13px;line-height:1.5">
        🟣 IA / INFERIDO <strong>nunca</strong> se convierte automáticamente en 🟢 ORIGINAL.<br><br>
        ⚪ DESCONOCIDO <strong>nunca</strong> se convierte automáticamente en 🔵 RECONSTRUIDO.<br><br>
        Solo el usuario (o un proceso explícito documentado) puede elevar el nivel de autenticidad.
      </p>
    </div>

    <div class="card">
      <h3>Almacenamiento</h3>
      <p style="font-size:13px">Todo se guarda localmente en tu navegador (localStorage).<br>
      No se envía a ningún servidor.</p>
      <div class="btn-row" style="margin-top:12px">
        <button class="btn secondary" onclick="exportData()">Exportar JSON</button>
        <button class="btn ghost" onclick="resetAll()">Reset</button>
      </div>
    </div>
  `;
}

async function exportData() {
  try {
    const json = await Storage.exportJSON();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'xn-memory-backup.json';
    a.click();
    URL.revokeObjectURL(url);
    toast('Backup exportado');
  } catch (e) {
    console.error(e);
    toast('Error al exportar');
  }
}

async function resetAll() {
  if (!confirm('¿Borrar todas las memorias locales y restaurar datos de ejemplo?')) return;
  try {
    await Storage.clear();
    state.data = await Storage.load();
    await updateStorageStatus();
    toast('Datos restaurados');
    render();
  } catch (e) {
    console.error(e);
    toast('Error al resetear');
  }
}

// Exponer funciones usadas en HTML
window.viewMemory = viewMemory;
window.openHolo = openHolo;
window.exportData = exportData;
window.resetAll = resetAll;
window.render = render;

// Service Worker (PWA offline)
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("./sw.js").catch(() => {});
}

// Start
init();
