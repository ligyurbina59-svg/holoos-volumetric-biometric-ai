package com.holoos.ai.fusion

import kotlin.math.sqrt
import kotlin.math.sin
import kotlin.math.cos
import kotlin.math.atan2
import kotlin.math.asin

/**
 * Madgwick AHRS (Attitude and Heading Reference System)
 *
 * Fusiona acelerómetro + giroscopio (+ magnetómetro opcional)
 * para obtener orientación en quaternion.
 *
 * Referencia: Sebastian O.H. Madgwick, 2010
 * "An efficient orientation filter for inertial and inertial/magnetic sensor arrays"
 *
 * Uso en HOLOOS:
 *   val filter = MadgwickAHRS(samplePeriod = 1f / 50f)
 *   filter.update(gx, gy, gz, ax, ay, az)           // 6DOF
 *   filter.update(gx, gy, gz, ax, ay, az, mx, my, mz) // 9DOF
 *   val (roll, pitch, yaw) = filter.eulerAngles()
 *   val motionConfidence = filter.motionConfidence()
 */

class MadgwickAHRS(
    /** Periodo de muestreo en segundos (ej. 1/50 = 50 Hz) */
    var samplePeriod: Float = 1f / 50f,

    /**
     * Ganancia del filtro (beta).
     * Más alto = más peso a acelerómetro/magnetómetro (más estable, más lag).
     * Más bajo = más peso a giroscopio (más reactivo, más drift).
     * Rango típico: 0.01 – 0.2
     */
    var beta: Float = 0.1f
) {
    // Quaternion de orientación (normalizado): q0 + q1·i + q2·j + q3·k
    var q0: Float = 1f
        private set
    var q1: Float = 0f
        private set
    var q2: Float = 0f
        private set
    var q3: Float = 0f
        private set

    /** Última magnitud de aceleración (útil para detectar movimiento libre) */
    var lastAccelMagnitude: Float = 1f
        private set

    /** Última tasa angular (rad/s) */
    var lastGyroMagnitude: Float = 0f
        private set

    // ----------------------------------------------------------
    // 6DOF: giroscopio + acelerómetro
    // ----------------------------------------------------------
    fun update(
        gx: Float, gy: Float, gz: Float,   // rad/s
        ax: Float, ay: Float, az: Float    // m/s² o g (normalizado internamente)
    ) {
        var axn = ax
        var ayn = ay
        var azn = az

        // Magnitud acelerómetro
        var norm = sqrt(axn * axn + ayn * ayn + azn * azn)
        lastAccelMagnitude = norm
        lastGyroMagnitude = sqrt(gx * gx + gy * gy + gz * gz)

        if (norm < 1e-6f) return // evitar división por cero
        norm = 1f / norm
        axn *= norm
        ayn *= norm
        azn *= norm

        // Auxiliares del quaternion actual
        val _2q0 = 2f * q0
        val _2q1 = 2f * q1
        val _2q2 = 2f * q2
        val _2q3 = 2f * q3
        val _4q0 = 4f * q0
        val _4q1 = 4f * q1
        val _4q2 = 4f * q2
        val _8q1 = 8f * q1
        val _8q2 = 8f * q2
        val q0q0 = q0 * q0
        val q1q1 = q1 * q1
        val q2q2 = q2 * q2
        val q3q3 = q3 * q3

        // Gradiente del error (objetivo: gravedad = [0, 0, 1] en marco del sensor)
        var s0 = _4q0 * q2q2 + _2q2 * axn + _4q0 * q1q1 - _2q1 * ayn
        var s1 = _4q1 * q3q3 - _2q3 * axn + 4f * q0q0 * q1 - _2q0 * ayn - _4q1 + _8q1 * q1q1 + _8q1 * q2q2 + _4q1 * azn
        var s2 = 4f * q0q0 * q2 + _2q0 * axn + _4q2 * q3q3 - _2q3 * ayn - _4q2 + _8q2 * q1q1 + _8q2 * q2q2 + _4q2 * azn
        var s3 = 4f * q1q1 * q3 - _2q1 * axn + 4f * q2q2 * q3 - _2q2 * ayn

        // Normalizar el paso del gradiente
        norm = sqrt(s0 * s0 + s1 * s1 + s2 * s2 + s3 * s3)
        if (norm > 1e-6f) {
            norm = 1f / norm
            s0 *= norm
            s1 *= norm
            s2 *= norm
            s3 *= norm
        }

        // Derivada del quaternion desde giroscopio
        val qDot0 = 0.5f * (-q1 * gx - q2 * gy - q3 * gz) - beta * s0
        val qDot1 = 0.5f * (q0 * gx + q2 * gz - q3 * gy) - beta * s1
        val qDot2 = 0.5f * (q0 * gy - q1 * gz + q3 * gx) - beta * s2
        val qDot3 = 0.5f * (q0 * gz + q1 * gy - q2 * gx) - beta * s3

        // Integrar
        q0 += qDot0 * samplePeriod
        q1 += qDot1 * samplePeriod
        q2 += qDot2 * samplePeriod
        q3 += qDot3 * samplePeriod

        normalizeQuaternion()
    }

    // ----------------------------------------------------------
    // 9DOF: giroscopio + acelerómetro + magnetómetro
    // ----------------------------------------------------------
    fun update(
        gx: Float, gy: Float, gz: Float,
        ax: Float, ay: Float, az: Float,
        mx: Float, my: Float, mz: Float
    ) {
        var axn = ax; var ayn = ay; var azn = az
        var mxn = mx; var myn = my; var mzn = mz

        lastAccelMagnitude = sqrt(ax * ax + ay * ay + az * az)
        lastGyroMagnitude = sqrt(gx * gx + gy * gy + gz * gz)

        // Normalizar acelerómetro
        var norm = sqrt(axn * axn + ayn * ayn + azn * azn)
        if (norm < 1e-6f) {
            // Sin accel válido → solo gyro (degradado)
            updateGyroOnly(gx, gy, gz)
            return
        }
        norm = 1f / norm
        axn *= norm; ayn *= norm; azn *= norm

        // Normalizar magnetómetro
        norm = sqrt(mxn * mxn + myn * myn + mzn * mzn)
        if (norm < 1e-6f) {
            // Sin mag → caer a 6DOF
            update(gx, gy, gz, ax, ay, az)
            return
        }
        norm = 1f / norm
        mxn *= norm; myn *= norm; mzn *= norm

        // Referencias auxiliares
        val _2q0mx = 2f * q0 * mxn
        val _2q0my = 2f * q0 * myn
        val _2q0mz = 2f * q0 * mzn
        val _2q1mx = 2f * q1 * mxn
        val _2q0 = 2f * q0
        val _2q1 = 2f * q1
        val _2q2 = 2f * q2
        val _2q3 = 2f * q3
        val _2q0q2 = 2f * q0 * q2
        val _2q2q3 = 2f * q2 * q3
        val q0q0 = q0 * q0
        val q0q1 = q0 * q1
        val q0q2 = q0 * q2
        val q0q3 = q0 * q3
        val q1q1 = q1 * q1
        val q1q2 = q1 * q2
        val q1q3 = q1 * q3
        val q2q2 = q2 * q2
        val q2q3 = q2 * q3
        val q3q3 = q3 * q3

        // Campo magnético de referencia
        val hx = mxn * q0q0 - _2q0my * q3 + _2q0mz * q2 + mxn * q1q1 + _2q1 * myn * q2 +
            _2q1 * mzn * q3 - mxn * q2q2 - mxn * q3q3
        val hy = _2q0mx * q3 + myn * q0q0 - _2q0mz * q1 + _2q1mx * q2 - myn * q1q1 +
            myn * q2q2 + _2q2 * mzn * q3 - myn * q3q3
        val _2bx = sqrt(hx * hx + hy * hy)
        val _2bz = -_2q0mx * q2 + _2q0my * q1 + mzn * q0q0 + _2q1mx * q3 - mzn * q1q1 +
            _2q2 * myn * q3 - mzn * q2q2 + mzn * q3q3
        val _4bx = 2f * _2bx
        val _4bz = 2f * _2bz

        // Gradiente
        var s0 = -_2q2 * (2f * q1q3 - _2q0q2 - axn) + _2q1 * (2f * q0q1 + _2q2q3 - ayn) -
            _2bz * q2 * (_2bx * (0.5f - q2q2 - q3q3) + _2bz * (q1q3 - q0q2) - mxn) +
            (-_2bx * q3 + _2bz * q1) * (_2bx * (q1q2 - q0q3) + _2bz * (q0q1 + q2q3) - myn) +
            _2bx * q2 * (_2bx * (q0q2 + q1q3) + _2bz * (0.5f - q1q1 - q2q2) - mzn)

        var s1 = _2q3 * (2f * q1q3 - _2q0q2 - axn) + _2q0 * (2f * q0q1 + _2q2q3 - ayn) -
            4f * q1 * (1f - 2f * q1q1 - 2f * q2q2 - azn) +
            _2bz * q3 * (_2bx * (0.5f - q2q2 - q3q3) + _2bz * (q1q3 - q0q2) - mxn) +
            (_2bx * q2 + _2bz * q0) * (_2bx * (q1q2 - q0q3) + _2bz * (q0q1 + q2q3) - myn) +
            (_2bx * q3 - _4bz * q1) * (_2bx * (q0q2 + q1q3) + _2bz * (0.5f - q1q1 - q2q2) - mzn)

        var s2 = -_2q0 * (2f * q1q3 - _2q0q2 - axn) + _2q3 * (2f * q0q1 + _2q2q3 - ayn) -
            4f * q2 * (1f - 2f * q1q1 - 2f * q2q2 - azn) +
            (-_4bx * q2 - _2bz * q0) * (_2bx * (0.5f - q2q2 - q3q3) + _2bz * (q1q3 - q0q2) - mxn) +
            (_2bx * q1 + _2bz * q3) * (_2bx * (q1q2 - q0q3) + _2bz * (q0q1 + q2q3) - myn) +
            (_2bx * q0 - _4bz * q2) * (_2bx * (q0q2 + q1q3) + _2bz * (0.5f - q1q1 - q2q2) - mzn)

        var s3 = _2q1 * (2f * q1q3 - _2q0q2 - axn) + _2q2 * (2f * q0q1 + _2q2q3 - ayn) +
            (-_4bx * q3 + _2bz * q1) * (_2bx * (0.5f - q2q2 - q3q3) + _2bz * (q1q3 - q0q2) - mxn) +
            (-_2bx * q0 + _2bz * q2) * (_2bx * (q1q2 - q0q3) + _2bz * (q0q1 + q2q3) - myn) +
            _2bx * q1 * (_2bx * (q0q2 + q1q3) + _2bz * (0.5f - q1q1 - q2q2) - mzn)

        norm = sqrt(s0 * s0 + s1 * s1 + s2 * s2 + s3 * s3)
        if (norm > 1e-6f) {
            norm = 1f / norm
            s0 *= norm; s1 *= norm; s2 *= norm; s3 *= norm
        }

        val qDot0 = 0.5f * (-q1 * gx - q2 * gy - q3 * gz) - beta * s0
        val qDot1 = 0.5f * (q0 * gx + q2 * gz - q3 * gy) - beta * s1
        val qDot2 = 0.5f * (q0 * gy - q1 * gz + q3 * gx) - beta * s2
        val qDot3 = 0.5f * (q0 * gz + q1 * gy - q2 * gx) - beta * s3

        q0 += qDot0 * samplePeriod
        q1 += qDot1 * samplePeriod
        q2 += qDot2 * samplePeriod
        q3 += qDot3 * samplePeriod

        normalizeQuaternion()
    }

    /** Solo giroscopio (cuando accel/mag no son fiables) */
    private fun updateGyroOnly(gx: Float, gy: Float, gz: Float) {
        val qDot0 = 0.5f * (-q1 * gx - q2 * gy - q3 * gz)
        val qDot1 = 0.5f * (q0 * gx + q2 * gz - q3 * gy)
        val qDot2 = 0.5f * (q0 * gy - q1 * gz + q3 * gx)
        val qDot3 = 0.5f * (q0 * gz + q1 * gy - q2 * gx)

        q0 += qDot0 * samplePeriod
        q1 += qDot1 * samplePeriod
        q2 += qDot2 * samplePeriod
        q3 += qDot3 * samplePeriod
        normalizeQuaternion()
    }

    private fun normalizeQuaternion() {
        val norm = 1f / sqrt(q0 * q0 + q1 * q1 + q2 * q2 + q3 * q3)
        q0 *= norm
        q1 *= norm
        q2 *= norm
        q3 *= norm
    }

    // ----------------------------------------------------------
    // Salidas útiles para HOLOOS
    // ----------------------------------------------------------

    /** Ángulos de Euler en radianes: Triple(roll, pitch, yaw) */
    fun eulerAngles(): Triple<Float, Float, Float> {
        val roll = atan2(2f * (q0 * q1 + q2 * q3), 1f - 2f * (q1 * q1 + q2 * q2))
        val sinp = 2f * (q0 * q2 - q3 * q1)
        val pitch = if (sinp.absoluteValue >= 1f) {
            (if (sinp > 0) PI / 2 else -PI / 2).toFloat()
        } else {
            asin(sinp)
        }
        val yaw = atan2(2f * (q0 * q3 + q1 * q2), 1f - 2f * (q2 * q2 + q3 * q3))
        return Triple(roll, pitch, yaw)
    }

    /** Ángulos en grados */
    fun eulerAnglesDegrees(): Triple<Float, Float, Float> {
        val (r, p, y) = eulerAngles()
        val k = 180f / PI.toFloat()
        return Triple(r * k, p * k, y * k)
    }

    /**
     * Confianza de movimiento para BiometricSignal(MOTION / GESTURE).
     * Combina desviación de gravedad + tasa angular.
     */
    fun motionConfidence(): Float {
        // En reposo ideal |a| ≈ 1g
        val accelDeviation = (lastAccelMagnitude - 1f).absoluteValue.coerceIn(0f, 2f)
        val gyroEnergy = lastGyroMagnitude.coerceIn(0f, 5f)

        val fromAccel = (accelDeviation / 0.4f).coerceIn(0f, 1f)
        val fromGyro = (gyroEnergy / 1.5f).coerceIn(0f, 1f)

        return (0.45f * fromAccel + 0.55f * fromGyro).coerceIn(0f, 1f)
    }

    /** Quaternion como array [w, x, y, z] */
    fun quaternion(): FloatArray = floatArrayOf(q0, q1, q2, q3)

    fun reset() {
        q0 = 1f; q1 = 0f; q2 = 0f; q3 = 0f
        lastAccelMagnitude = 1f
        lastGyroMagnitude = 0f
    }

    private val Float.absoluteValue: Float
        get() = if (this < 0) -this else this
}

// ----------------------------------------------------------
// Adaptador hacia BiometricSignal (HOLOOS)
// ----------------------------------------------------------

/**
 * Convierte la salida del Madgwick en señales del pipeline HOLO.
 *
 * Ejemplo:
 *   val madgwick = MadgwickAHRS(1f/50f)
 *   // en cada tick del sensor:
 *   madgwick.update(gx, gy, gz, ax, ay, az)
 *   val signals = MadgwickBridge.toSignals(madgwick)
 */
object MadgwickBridge {

    fun toSignals(filter: MadgwickAHRS): List<BiometricSignalLite> {
        val motion = filter.motionConfidence()
        val (roll, pitch, yaw) = filter.eulerAngles()

        return listOf(
            BiometricSignalLite(
                type = "MOTION",
                confidence = motion,
                features = mapOf(
                    "gyroMagnitude" to filter.lastGyroMagnitude,
                    "accelMagnitude" to filter.lastAccelMagnitude
                )
            ),
            BiometricSignalLite(
                type = "GESTURE",
                confidence = (motion * 0.85f).coerceIn(0f, 1f),
                features = mapOf(
                    "roll" to roll,
                    "pitch" to pitch,
                    "yaw" to yaw
                )
            )
        )
    }
}

/** Señal ligera (evita dependencia circular con el resto del paquete) */
data class BiometricSignalLite(
    val type: String,
    val confidence: Float,
    val features: Map<String, Float> = emptyMap()
)
