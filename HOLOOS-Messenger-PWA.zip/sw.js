const CACHE = 'holoos-messenger-v1';
const ASSETS = [
  './', './index.html', './css/app.css', './css/messenger.css',
  './js/storage.js', './js/volumetric.js', './js/holoscene.js',
  './js/holoos-engine.js', './js/messenger.js', './js/app.js',
  './manifest.json', './icons/icon-192.png', './icons/icon-512.png'
];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  e.respondWith(caches.match(e.request).then(c => c || fetch(e.request).catch(() => caches.match('./index.html'))));
});
