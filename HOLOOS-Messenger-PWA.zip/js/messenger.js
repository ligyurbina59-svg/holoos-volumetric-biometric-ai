/**
 * HOLOOS Messenger — chats, contactos, mensajes locales + gancho holográfico
 */
const Messenger = {
  async ensureSchema() {
    const data = await Storage.load();
    if (!data.chats) data.chats = [];
    if (!data.messages) data.messages = {};
    // seed demo
    if (data.chats.length === 0 && data.people && data.people.length) {
      const p = data.people[0];
      const chatId = 'chat_' + p.id;
      data.chats.push({
        id: chatId,
        peerId: p.id,
        title: p.name,
        avatar: p.avatar || '👤',
        lastMessage: 'La mesa siempre tiene un plato de más.',
        lastAt: new Date().toISOString(),
        unread: 0
      });
      data.messages[chatId] = [
        {
          id: 'm1',
          from: 'peer',
          text: '¿Recuerdas el viaje de julio?',
          at: '2019-07-14T18:00:00Z',
          authenticity: 'ORIGINAL'
        },
        {
          id: 'm2',
          from: 'me',
          text: 'Sí, abuela. Nunca lo olvido.',
          at: '2019-07-14T18:05:00Z',
          authenticity: 'ORIGINAL'
        },
        {
          id: 'm3',
          from: 'peer',
          text: 'La mesa siempre tiene un plato de más.',
          at: new Date().toISOString(),
          authenticity: 'ORIGINAL'
        }
      ];
      // persist via storage if available
      if (Storage._saveRaw) await Storage._saveRaw(data);
      else {
        // fallback: stash on window for session
        window.__holoMsgSeed = data;
      }
    }
    return data;
  },

  async getChats() {
    const data = await this._data();
    return (data.chats || []).slice().sort((a, b) => (b.lastAt || '').localeCompare(a.lastAt || ''));
  },

  async getMessages(chatId) {
    const data = await this._data();
    return (data.messages && data.messages[chatId]) || [];
  },

  async sendMessage(chatId, text) {
    if (!text || !text.trim()) return null;
    const data = await this._data();
    if (!data.messages) data.messages = {};
    if (!data.messages[chatId]) data.messages[chatId] = [];
    const msg = {
      id: 'm_' + Date.now().toString(36),
      from: 'me',
      text: text.trim(),
      at: new Date().toISOString(),
      authenticity: 'ORIGINAL'
    };
    data.messages[chatId].push(msg);
    const chat = (data.chats || []).find(c => c.id === chatId);
    if (chat) {
      chat.lastMessage = msg.text;
      chat.lastAt = msg.at;
    }
    await this._persist(data);
    return msg;
  },

  async createChat(name, initialMsg) {
    const data = await this._data();
    if (!data.people) data.people = [];
    if (!data.chats) data.chats = [];
    if (!data.messages) data.messages = {};

    let person = data.people.find(p => p.name.toLowerCase() === name.toLowerCase());
    if (!person) {
      person = {
        id: 'p_' + Date.now().toString(36),
        name,
        avatar: '👤',
        relation: 'Contacto',
        years: '',
        quote: ''
      };
      data.people.push(person);
    }

    const chatId = 'chat_' + person.id + '_' + Date.now().toString(36).slice(-4);
    const chat = {
      id: chatId,
      peerId: person.id,
      title: person.name,
      avatar: person.avatar,
      lastMessage: initialMsg || '',
      lastAt: new Date().toISOString(),
      unread: 0
    };
    data.chats.unshift(chat);
    data.messages[chatId] = [];
    if (initialMsg && initialMsg.trim()) {
      data.messages[chatId].push({
        id: 'm_' + Date.now().toString(36),
        from: 'me',
        text: initialMsg.trim(),
        at: new Date().toISOString(),
        authenticity: 'ORIGINAL'
      });
      chat.lastMessage = initialMsg.trim();
    }
    await this._persist(data);
    return { chat, person };
  },

  async _data() {
    let data = await Storage.load();
    if (window.__holoMsgSeed) {
      data = { ...data, ...window.__holoMsgSeed, people: data.people };
    }
    if (!data.chats) data.chats = [];
    if (!data.messages) data.messages = {};
    return data;
  },

  async _persist(data) {
    window.__holoMsgSeed = data;
    // Try to keep people in IndexedDB
    try {
      if (data.people) {
        for (const p of data.people) {
          const existing = await Storage.getPerson(p.id);
          if (!existing) await Storage.addPerson(p);
        }
      }
    } catch (e) {
      console.warn('persist people', e);
    }
    try {
      localStorage.setItem('holoos_messenger_v1', JSON.stringify({
        chats: data.chats,
        messages: data.messages
      }));
    } catch (e) {}
  },

  loadLocalOverlay() {
    try {
      const raw = localStorage.getItem('holoos_messenger_v1');
      if (raw) {
        const o = JSON.parse(raw);
        window.__holoMsgSeed = window.__holoMsgSeed || {};
        window.__holoMsgSeed.chats = o.chats || [];
        window.__holoMsgSeed.messages = o.messages || {};
      }
    } catch (e) {}
  }
};

window.Messenger = Messenger;
