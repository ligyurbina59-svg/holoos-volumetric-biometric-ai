/**
 * HOLOOS Messenger — UI: chats + hologramas + memoria
 */
const $ = (id) => document.getElementById(id);

const state = {
  tab: 'chats',
  data: null,
  activeChatId: null,
  presenceSession: null
};

async function init() {
  try {
    Messenger.loadLocalOverlay();
    state.data = await Storage.load();
    await Messenger.ensureSchema();
    state.data = await Storage.load();
    // merge messenger overlay
    const overlay = window.__holoMsgSeed || {};
    if (overlay.chats) state.data.chats = overlay.chats;
    if (overlay.messages) state.data.messages = overlay.messages;
    bindEvents();
    await updateStatus();
    render();
  } catch (e) {
    console.error(e);
    toast('Error al iniciar');
  }
}

async function updateStatus() {
  try {
    const info = await Storage.info();
    const chats = await Messenger.getChats();
    const el = $('storage-status');
    if (el) el.textContent = `${chats.length} chats · IDB`;
  } catch (_) {}
}

function bindEvents() {
  document.querySelectorAll('.tab').forEach(t => {
    t.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
      t.classList.add('active');
      state.tab = t.dataset.tab;
      closeChat();
      stopHolo();
      render();
    });
  });

  $('btn-new').onclick = () => openModal();
  $('m-cancel').onclick = () => closeModal();
  $('m-save').onclick = saveNewChat;
  $('chat-back').onclick = () => closeChat();
  $('chat-holo').onclick = () => {
    const chats = state.data.chats || [];
    const chat = chats.find(c => c.id === state.activeChatId);
    if (chat && chat.peerId) openHolo(chat.peerId);
  };
  $('btn-send').onclick = sendCurrent;
  $('msg-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') sendCurrent();
  });
  $('h-close').onclick = stopHolo;
  $('h-voice').onclick = () => toast('Voz real · memoria ORIGINAL');
  $('btn-attach').onclick = () => toast('Adjuntar · foto / audio (próximamente)');
}

function toast(msg) {
  const el = $('toast');
  el.textContent = msg;
  el.classList.remove('hidden');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.add('hidden'), 2400);
}

function openModal() {
  $('m-name').value = '';
  $('m-msg').value = '';
  $('modal').classList.remove('hidden');
}
function closeModal() {
  $('modal').classList.add('hidden');
}

async function saveNewChat() {
  const name = $('m-name').value.trim();
  const msg = $('m-msg').value.trim();
  if (!name) { toast('Escribe un nombre'); return; }
  try {
    const { chat } = await Messenger.createChat(name, msg);
    state.data.chats = await Messenger.getChats();
    closeModal();
    toast('Chat creado');
    openChat(chat.id);
  } catch (e) {
    console.error(e);
    toast('Error al crear chat');
  }
}

async function openChat(chatId) {
  state.activeChatId = chatId;
  const chats = await Messenger.getChats();
  const chat = chats.find(c => c.id === chatId);
  if (!chat) return;

  $('peer-av').textContent = chat.avatar || '👤';
  $('peer-name').textContent = chat.title;
  $('peer-status').textContent = 'HOLO · presencia disponible';
  $('chat-view').classList.remove('hidden');
  await renderMessages(chatId);
  $('msg-input').focus();
}

function closeChat() {
  state.activeChatId = null;
  $('chat-view').classList.add('hidden');
}

async function renderMessages(chatId) {
  const msgs = await Messenger.getMessages(chatId);
  const box = $('chat-messages');
  box.innerHTML = msgs.map(m => `
    <div class="bubble ${m.from === 'me' ? 'me' : 'peer'}">
      <div class="bubble-text">${escapeHtml(m.text)}</div>
      <div class="bubble-meta">
        <span>${formatTime(m.at)}</span>
        ${m.authenticity ? `<span class="badge ${m.authenticity}">${authLabel(m.authenticity)}</span>` : ''}
      </div>
    </div>
  `).join('') || '<p class="empty-chat">Sin mensajes aún</p>';
  box.scrollTop = box.scrollHeight;
}

async function sendCurrent() {
  const text = $('msg-input').value;
  if (!state.activeChatId || !text.trim()) return;
  await Messenger.sendMessage(state.activeChatId, text);
  $('msg-input').value = '';
  state.data.chats = await Messenger.getChats();
  await renderMessages(state.activeChatId);
  await updateStatus();
}

function escapeHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function formatTime(iso) {
  try {
    return new Date(iso).toLocaleString('es', { day:'numeric', month:'short', hour:'2-digit', minute:'2-digit' });
  } catch { return ''; }
}
function authLabel(c) {
  return ({ ORIGINAL:'🟢', RECONSTRUCTED:'🔵', INFERRED:'🟣', GENERATED:'🟠', UNKNOWN:'⚪' })[c] || c;
}

// ---- Holo ----
function openHolo(personId) {
  const person = (state.data.people || []).find(p => p.id === personId);
  if (!person) {
    toast('Sin persona vinculada');
    return;
  }
  $('holo-ui').classList.remove('hidden');
  $('h-name').textContent = person.name;
  $('h-quote').textContent = person.quote ? `“${person.quote}”` : '“Presencia del momento”';
  $('h-auth').innerHTML = '<span class="badge ORIGINAL">🟢 ORIGINAL</span>';

  const canvas = $('holo-canvas');
  if (!state.presenceSession) {
    state.presenceSession = new HoloosPresenceSession(canvas);
  }
  state.presenceSession.setPerson(person, ['ORIGINAL']);
  state.presenceSession.setContext({ personId: person.id, authLevels: ['ORIGINAL'] });
  state.presenceSession.start();
}

function stopHolo() {
  if (state.presenceSession) {
    try {
      const r = state.presenceSession.getProvenanceReport();
      if (r && !r.empty) console.log('[HOLO Provenance]', r);
    } catch (_) {}
    state.presenceSession.stop();
  }
  $('holo-ui').classList.add('hidden');
}

// ---- Tabs ----
function render() {
  const content = $('content');
  switch (state.tab) {
    case 'chats': content.innerHTML = renderChats(); break;
    case 'holo': content.innerHTML = renderHoloTab(); break;
    case 'memory': content.innerHTML = renderMemoryTab(); break;
    case 'contacts': content.innerHTML = renderContacts(); break;
    case 'truth': content.innerHTML = renderTruth(); break;
    default: content.innerHTML = renderChats();
  }
}

function renderChats() {
  const chats = state.data.chats || window.__holoMsgSeed?.chats || [];
  if (!chats.length) {
    return `<div class="empty"><div class="big">💬</div><p>No hay chats.<br>Pulsa ＋ para crear uno.</p></div>`;
  }
  return chats.map(c => `
    <div class="card chat-row" onclick="openChat('${c.id}')">
      <div class="av">${c.avatar || '👤'}</div>
      <div class="info">
        <strong>${escapeHtml(c.title)}</strong>
        <span>${escapeHtml(c.lastMessage || 'Sin mensajes')}</span>
      </div>
      <div class="chat-time">${formatTime(c.lastAt)}</div>
    </div>
  `).join('');
}

function renderHoloTab() {
  const people = state.data.people || [];
  return `
    <div class="card">
      <h3>✦ Presencia holográfica</h3>
      <p>Proyecta una presencia a partir de memorias y señales. <strong>No recrea a la persona.</strong></p>
    </div>
    ${people.map(p => `
      <div class="card chat-row" onclick="openHolo('${p.id}')">
        <div class="av">${p.avatar || '👤'}</div>
        <div class="info">
          <strong>${escapeHtml(p.name)}</strong>
          <span>${p.relation || 'Contacto'} · tocar para presencia</span>
        </div>
      </div>
    `).join('') || '<div class="empty">Sin contactos</div>'}
  `;
}

function renderMemoryTab() {
  const mems = (state.data.memories || []).filter(m => m.status !== 'DELETED');
  return `
    <div class="card">
      <h3>🧠 Memoria</h3>
      <p>Memory Objects con autenticidad 🟢🔵🟣🟠⚪</p>
    </div>
    ${mems.map(m => `
      <div class="card">
        <h3><span class="badge ${m.authenticity}">${authLabel(m.authenticity)} ${m.authenticity}</span> ${escapeHtml(m.title)}</h3>
        <p>${escapeHtml(m.note || '')}</p>
      </div>
    `).join('') || '<div class="empty">Sin memorias</div>'}
  `;
}

function renderContacts() {
  const people = state.data.people || [];
  return `
    <div class="card"><h3>♡ Contactos</h3><p>Personas vinculadas a chats y memorias.</p></div>
    ${people.map(p => `
      <div class="card chat-row">
        <div class="av">${p.avatar || '👤'}</div>
        <div class="info">
          <strong>${escapeHtml(p.name)}</strong>
          <span>${p.relation || ''} ${p.years ? '· ' + p.years : ''}</span>
        </div>
        <button class="icon-btn" onclick="openHolo('${p.id}')" title="Holo">✦</button>
      </div>
    `).join('') || '<div class="empty">Sin contactos</div>'}
  `;
}

function renderTruth() {
  return `
    <div class="card">
      <h3>◎ Sistema de autenticidad</h3>
      <p>HOLO nunca confunde lo real con lo generado.</p>
      <div class="auth-legend" style="margin-top:12px">
        <div>🟢 ORIGINAL — evidencia real</div>
        <div>🔵 RECONSTRUIDO — completado con base</div>
        <div>🟣 IA / INFERIDO — interpretación</div>
        <div>🟠 GENERADO — sintético</div>
        <div>⚪ DESCONOCIDO — sin verificar</div>
      </div>
    </div>
    <div class="card">
      <h3>Mensajería + Hologramas</h3>
      <p style="font-size:13px;line-height:1.5">
        Chats locales · presencia volumétrica · memorias con procedencia.<br>
        <strong>HOLO no devuelve vidas. Preserva memorias.</strong>
      </p>
    </div>
  `;
}

window.openChat = openChat;
window.openHolo = openHolo;
window.render = render;

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('./sw.js').catch(() => {});
}

init();
