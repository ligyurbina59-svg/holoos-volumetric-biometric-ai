/**
 * XN-Memory · IndexedDB Storage Engine
 * Mayor capacidad, datos estructurados, índices y consultas eficientes
 */

const DB_NAME = 'XNMemoryDB';
const DB_VERSION = 1;
const STORE_MEMORIES = 'memories';
const STORE_PEOPLE = 'people';
const STORE_SETTINGS = 'settings';
const STORE_META = 'meta';

const defaultPeople = [
  {
    id: 'p_abuela',
    name: 'Abuela Rosa',
    avatar: '👵',
    relation: 'Abuela',
    years: '1948 – 2022',
    quote: 'La mesa siempre tiene un plato de más.'
  }
];

const defaultMemories = [
  {
    id: 'mem_8f3a2b1c',
    title: 'Primer viaje con mi abuela',
    personId: 'p_abuela',
    domain: 'PERSONAL',
    subtype: 'EXPERIENCIA',
    authenticity: 'ORIGINAL',
    dateStart: '2019-07-12',
    dateEnd: '2019-07-15',
    note: 'Viaje familiar de cuatro días.',
    evidence: [
      { id: 'img_001', type: 'IMAGE', authenticity: 'ORIGINAL', label: 'Foto llegada' },
      { id: 'img_002', type: 'IMAGE', authenticity: 'ORIGINAL', label: 'Foto convivencia' },
      { id: 'voz_abuela_01', type: 'AUDIO', authenticity: 'ORIGINAL', label: 'Voz de abuela' }
    ],
    timeline: [
      { id: 'ev1', date: '2019-07-12', label: 'Llegada y primer paseo', authenticity: 'ORIGINAL' },
      { id: 'ev2', date: '2019-07-13', label: 'Días de convivencia', authenticity: 'INFERRED' },
      { id: 'ev3', date: '2019-07-15', label: 'Regreso', authenticity: 'UNKNOWN' }
    ],
    status: 'ACTIVE',
    createdAt: '2024-03-02T11:20:00Z',
    updatedAt: new Date().toISOString()
  }
];

// ----------------------------------------------------------
// IndexedDB helpers
// ----------------------------------------------------------
function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);

    req.onupgradeneeded = (event) => {
      const db = event.target.result;

      if (!db.objectStoreNames.contains(STORE_MEMORIES)) {
        const memStore = db.createObjectStore(STORE_MEMORIES, { keyPath: 'id' });
        memStore.createIndex('by_person', 'personId', { unique: false });
        memStore.createIndex('by_status', 'status', { unique: false });
        memStore.createIndex('by_auth', 'authenticity', { unique: false });
        memStore.createIndex('by_date', 'dateStart', { unique: false });
      }

      if (!db.objectStoreNames.contains(STORE_PEOPLE)) {
        db.createObjectStore(STORE_PEOPLE, { keyPath: 'id' });
      }

      if (!db.objectStoreNames.contains(STORE_SETTINGS)) {
        db.createObjectStore(STORE_SETTINGS, { keyPath: 'key' });
      }

      if (!db.objectStoreNames.contains(STORE_META)) {
        db.createObjectStore(STORE_META, { keyPath: 'key' });
      }
    };

    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function txDone(tx) {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error || new Error('Transaction aborted'));
  });
}

function reqToPromise(req) {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

// ----------------------------------------------------------
// Storage API
// ----------------------------------------------------------
const Storage = {
  _db: null,
  _ready: null,

  async init() {
    if (this._ready) return this._ready;

    this._ready = (async () => {
      this._db = await openDB();
      const peopleCount = await this._count(STORE_PEOPLE);
      if (peopleCount === 0) {
        await this._seed();
      }
      return this._db;
    })();

    return this._ready;
  },

  async _seed() {
    const db = this._db;
    const tx = db.transaction([STORE_PEOPLE, STORE_MEMORIES, STORE_META], 'readwrite');

    const peopleStore = tx.objectStore(STORE_PEOPLE);
    const memStore = tx.objectStore(STORE_MEMORIES);
    const metaStore = tx.objectStore(STORE_META);

    for (const p of defaultPeople) peopleStore.put(p);
    for (const m of defaultMemories) memStore.put(m);

    metaStore.put({ key: 'version', value: DB_VERSION });
    metaStore.put({ key: 'createdAt', value: new Date().toISOString() });

    await txDone(tx);
  },

  async _count(storeName) {
    const db = await this.init();
    const tx = db.transaction(storeName, 'readonly');
    const count = await reqToPromise(tx.objectStore(storeName).count());
    await txDone(tx);
    return count;
  },

  // ---------- PEOPLE ----------
  async getPeople() {
    const db = await this.init();
    const tx = db.transaction(STORE_PEOPLE, 'readonly');
    const list = await reqToPromise(tx.objectStore(STORE_PEOPLE).getAll());
    await txDone(tx);
    return list || [];
  },

  async getPerson(id) {
    const db = await this.init();
    const tx = db.transaction(STORE_PEOPLE, 'readonly');
    const person = await reqToPromise(tx.objectStore(STORE_PEOPLE).get(id));
    await txDone(tx);
    return person || null;
  },

  async addPerson(person) {
    const db = await this.init();
    person.id = person.id || 'p_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    const tx = db.transaction(STORE_PEOPLE, 'readwrite');
    tx.objectStore(STORE_PEOPLE).put(person);
    await txDone(tx);
    return person;
  },

  async updatePerson(id, patch) {
    const person = await this.getPerson(id);
    if (!person) return null;
    const updated = { ...person, ...patch };
    const db = await this.init();
    const tx = db.transaction(STORE_PEOPLE, 'readwrite');
    tx.objectStore(STORE_PEOPLE).put(updated);
    await txDone(tx);
    return updated;
  },

  // ---------- MEMORIES ----------
  async getMemories({ includeDeleted = false } = {}) {
    const db = await this.init();
    const tx = db.transaction(STORE_MEMORIES, 'readonly');
    let list = await reqToPromise(tx.objectStore(STORE_MEMORIES).getAll());
    await txDone(tx);
    list = list || [];
    if (!includeDeleted) list = list.filter(m => m.status !== 'DELETED');
    list.sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
    return list;
  },

  async getMemory(id) {
    const db = await this.init();
    const tx = db.transaction(STORE_MEMORIES, 'readonly');
    const mem = await reqToPromise(tx.objectStore(STORE_MEMORIES).get(id));
    await txDone(tx);
    return mem || null;
  },

  async addMemory(memory) {
    const db = await this.init();
    memory.id = memory.id || 'mem_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    memory.createdAt = memory.createdAt || new Date().toISOString();
    memory.updatedAt = new Date().toISOString();
    memory.status = memory.status || 'ACTIVE';
    memory.evidence = memory.evidence || [];
    memory.timeline = memory.timeline || [];

    const tx = db.transaction(STORE_MEMORIES, 'readwrite');
    tx.objectStore(STORE_MEMORIES).put(memory);
    await txDone(tx);
    return memory;
  },

  async updateMemory(id, patch) {
    const mem = await this.getMemory(id);
    if (!mem) return null;
    const updated = { ...mem, ...patch, updatedAt: new Date().toISOString() };
    const db = await this.init();
    const tx = db.transaction(STORE_MEMORIES, 'readwrite');
    tx.objectStore(STORE_MEMORIES).put(updated);
    await txDone(tx);
    return updated;
  },

  async deleteMemory(id) {
    return this.updateMemory(id, {
      status: 'DELETED',
      deletedAt: new Date().toISOString()
    });
  },

  async getMemoriesByPerson(personId) {
    const db = await this.init();
    const tx = db.transaction(STORE_MEMORIES, 'readonly');
    const index = tx.objectStore(STORE_MEMORIES).index('by_person');
    const list = await reqToPromise(index.getAll(personId));
    await txDone(tx);
    return (list || []).filter(m => m.status !== 'DELETED');
  },

  // ---------- Compatibilidad con app.js ----------
  async load() {
    const [people, memories] = await Promise.all([
      this.getPeople(),
      this.getMemories({ includeDeleted: true })
    ]);
    return {
      version: DB_VERSION,
      people,
      memories,
      settings: { theme: 'dark', language: 'es' }
    };
  },

  // ---------- Export / Import / Clear ----------
  async exportJSON() {
    const data = await this.load();
    return JSON.stringify(data, null, 2);
  },

  async importJSON(jsonString) {
    try {
      const data = JSON.parse(jsonString);
      if (!Array.isArray(data.memories) || !Array.isArray(data.people)) {
        throw new Error('Formato inválido');
      }

      const db = await this.init();
      const tx = db.transaction([STORE_PEOPLE, STORE_MEMORIES], 'readwrite');
      tx.objectStore(STORE_PEOPLE).clear();
      tx.objectStore(STORE_MEMORIES).clear();

      for (const p of data.people) tx.objectStore(STORE_PEOPLE).put(p);
      for (const m of data.memories) tx.objectStore(STORE_MEMORIES).put(m);

      await txDone(tx);
      return true;
    } catch (e) {
      console.error('Import failed', e);
      return false;
    }
  },

  async clear() {
    const db = await this.init();
    const tx = db.transaction([STORE_PEOPLE, STORE_MEMORIES, STORE_META], 'readwrite');
    tx.objectStore(STORE_PEOPLE).clear();
    tx.objectStore(STORE_MEMORIES).clear();
    tx.objectStore(STORE_META).clear();
    await txDone(tx);
    await this._seed();
  },

  async info() {
    const [people, memories] = await Promise.all([
      this.getPeople(),
      this.getMemories()
    ]);

    let bytes = 0;
    try {
      const json = await this.exportJSON();
      bytes = new Blob([json]).size;
    } catch (_) {}

    return {
      engine: 'IndexedDB',
      bytes,
      memories: memories.length,
      people: people.length
    };
  }
};

window.Storage = Storage;
