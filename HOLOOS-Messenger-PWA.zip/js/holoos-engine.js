/**
 * HOLOOS Presence Engine — API de alto nivel
 *
 * Uso:
 *   val engine = HoloosPresenceEngine()
 *   val vizEngine = PresenceVisualizationEngine()
 *
 *   val output = engine.processWithPresence(signals, context, sourceMap)
 *   val scene  = vizEngine.buildPresenceScene(output)
 *   renderer.render(scene)
 *   val report = engine.getProvenanceReport()
 */

// ============================================================
// Tipos / estructuras
// ============================================================

/**
 * @typedef {Object} SensorSignal
 * @property {string} type - FACE_LANDMARKS | VOICE_FEATURES | MOTION | HEART_RATE | GESTURE | ENVIRONMENT
 * @property {number} confidence - 0..1
 * @property {Object} [features]
 * @property {string} [source] - camera | microphone | imu | system
 */

/**
 * @typedef {Object} PresenceContext
 * @property {Object} [memory] - Memory Object activo
 * @property {string} [personId]
 * @property {string[]} [authLevels] - 🟢🔵🟣🟠⚪ presentes
 * @property {Object} [spatial]
 * @property {number} [timestamp]
 */

/**
 * @typedef {Object} PresenceOutput
 * @property {Object} biometricState
 * @property {Object} inference
 * @property {Object} frame - VolumetricFrame
 * @property {Object} provenance
 * @property {number} timestamp
 */

// ============================================================
// HoloosPresenceEngine
// ============================================================
class HoloosPresenceEngine {
  constructor(options = {}) {
    this.ai = new VolumetricBiometricAI();
    this.history = [];
    this.maxHistory = options.maxHistory || 120;
    this.lastOutput = null;
    this.sourceMap = options.sourceMap || this.defaultSourceMap();
  }

  defaultSourceMap() {
    return {
      FACE_LANDMARKS: 'camera',
      VOICE_FEATURES: 'microphone',
      MOTION: 'imu',
      HEART_RATE: 'sensor',
      GESTURE: 'imu',
      ENVIRONMENT: 'system'
    };
  }

  /**
   * Procesa señales + contexto → PresenceOutput
   */
  processWithPresence(signals = [], context = {}, sourceMap = null) {
    const map = sourceMap || this.sourceMap;

    // Anotar procedencia de cada señal
    const annotated = signals.map(s => ({
      ...s,
      source: s.source || map[s.type] || 'unknown',
      confidence: Math.max(0, Math.min(1, s.confidence ?? 0))
    }));

    // Pipeline biométrico → volumétrico
    const result = this.ai.process(annotated, context.memory || {});

    // Provenance
    const provenance = {
      signalSources: annotated.map(s => ({
        type: s.type,
        source: s.source,
        confidence: s.confidence
      })),
      authLevels: context.authLevels || [],
      personId: context.personId || null,
      memoryId: context.memory?.id || null,
      mode: result.inference.responseMode,
      timestamp: Date.now()
    };

    const output = {
      biometricState: result.biometricState,
      inference: result.inference,
      frame: result.frame,
      provenance,
      timestamp: Date.now()
    };

    this.lastOutput = output;
    this.history.push({
      t: output.timestamp,
      mode: output.inference.responseMode,
      attention: output.biometricState.attention,
      interaction: output.biometricState.interaction
    });
    if (this.history.length > this.maxHistory) this.history.shift();

    return output;
  }

  /**
   * Genera señales simuladas (demo sin sensores reales)
   */
  captureSimulated(t = performance.now() / 1000) {
    return this.ai.simulateSignals(t);
  }

  /**
   * Informe de procedencia del último frame
   */
  getProvenanceReport() {
    if (!this.lastOutput) {
      return { empty: true, message: 'No presence processed yet' };
    }

    const p = this.lastOutput.provenance;
    const state = this.lastOutput.biometricState;

    return {
      timestamp: p.timestamp,
      mode: p.mode,
      personId: p.personId,
      memoryId: p.memoryId,
      authLevels: p.authLevels,
      signals: p.signalSources,
      biometric: {
        attention: +state.attention.toFixed(3),
        activity: +state.activity.toFixed(3),
        interaction: +state.interaction.toFixed(3)
      },
      principle: 'Huella biométrica del momento · NO es la persona',
      historySize: this.history.length
    };
  }

  getHistory() {
    return [...this.history];
  }
}

// ============================================================
// PresenceVisualizationEngine
// ============================================================
class PresenceVisualizationEngine {
  constructor(canvas) {
    this.builder = new HoloSceneBuilder(canvas);
    this.engine = null;
  }

  /**
   * Conecta el motor de presencia
   */
  attachEngine(engine) {
    this.engine = engine;
    this.builder.setAI(engine.ai);
  }

  /**
   * Construye la escena a partir del PresenceOutput
   */
  buildPresenceScene(output, person = null, authLevels = []) {
    if (person) this.builder.setPerson(person);
    if (authLevels.length) this.builder.setAuthLevels(authLevels);

    // El builder ya consume el frame internamente en su loop;
    // aquí devolvemos un descriptor de escena para el renderer.
    return {
      type: 'HOLO_PRESENCE_SCENE',
      frame: output.frame,
      mode: output.inference.responseMode,
      biometric: output.biometricState,
      provenance: output.provenance,
      layers: ['AmbientField', 'VolumeCloud', 'PresenceCore', 'InteractionField', 'AuthOverlay'],
      principle: 'Huella del momento · no es la persona'
    };
  }

  /**
   * Inicia el loop de visualización (usa el engine si está attached)
   */
  start(person, authLevels = []) {
    if (person) this.builder.setPerson(person);
    this.builder.setAuthLevels(authLevels);
    this.builder.start();
  }

  stop() {
    this.builder.stop();
  }

  /**
   * Render explícito de una escena (para uso manual)
   */
  render(scene) {
    // El HoloSceneBuilder ya dibuja en canvas en su loop.
    // Este método existe para compatibilidad con el patrón:
    //   renderer.render(scene)
    return scene;
  }
}

// ============================================================
// Helper de uso completo (un solo call site)
// ============================================================
class HoloosPresenceSession {
  constructor(canvas, options = {}) {
    this.engine = new HoloosPresenceEngine(options);
    this.viz = new PresenceVisualizationEngine(canvas);
    this.viz.attachEngine(this.engine);
    this.running = false;
    this.person = null;
    this.authLevels = [];
    this.context = {};
  }

  setPerson(person, authLevels = []) {
    this.person = person;
    this.authLevels = authLevels;
  }

  setContext(ctx) {
    this.context = ctx || {};
  }

  /**
   * Arranca la sesión de presencia
   */
  start() {
    this.running = true;
    this.viz.start(this.person, this.authLevels);
  }

  stop() {
    this.running = false;
    this.viz.stop();
  }

  /**
   * Un frame manual (si no se usa el loop interno del builder)
   */
  tick(signals = null) {
    const sensors = signals || this.engine.captureSimulated();
    const output = this.engine.processWithPresence(
      sensors,
      {
        ...this.context,
        personId: this.person?.id,
        authLevels: this.authLevels
      }
    );
    const scene = this.viz.buildPresenceScene(output, this.person, this.authLevels);
    this.viz.render(scene);
    return { output, scene };
  }

  getProvenanceReport() {
    return this.engine.getProvenanceReport();
  }
}

// Exponer API global
window.HoloosPresenceEngine = HoloosPresenceEngine;
window.PresenceVisualizationEngine = PresenceVisualizationEngine;
window.HoloosPresenceSession = HoloosPresenceSession;
