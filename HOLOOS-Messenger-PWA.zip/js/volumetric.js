/**
 * XN-Memory · Volumetric Biometric AI (JS port)
 * Señales → Processor → Inference → Renderer → HoloScene
 */

// ============================================================
// Tipos de señal
// ============================================================
const SignalType = {
  FACE_LANDMARKS: 'FACE_LANDMARKS',
  VOICE_FEATURES: 'VOICE_FEATURES',
  MOTION: 'MOTION',
  HEART_RATE: 'HEART_RATE',
  GESTURE: 'GESTURE',
  ENVIRONMENT: 'ENVIRONMENT'
};

// ============================================================
// BiometricProcessor
// ============================================================
class BiometricProcessor {
  constructor() {
    this.signals = [];
  }

  addSignal(type, confidence, features = {}) {
    const c = Math.max(0, Math.min(1, confidence));
    this.signals.push({ type, confidence: c, features });
  }

  clear() {
    this.signals = [];
  }

  buildState() {
    const avg = (type) => {
      const vals = this.signals.filter(s => s.type === type).map(s => s.confidence);
      return vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
    };

    const visual = avg(SignalType.FACE_LANDMARKS);
    const voice = avg(SignalType.VOICE_FEATURES);
    const motion = avg(SignalType.MOTION);
    const gesture = avg(SignalType.GESTURE);

    return {
      signals: [...this.signals],
      attention: Math.min(1, (visual + voice) / 2),
      activity: motion,
      interaction: Math.min(1, (motion + gesture) / 2)
    };
  }
}

// ============================================================
// InferenceEngine
// ============================================================
class InferenceEngine {
  infer(biometricState) {
    const { attention, activity, interaction } = biometricState;

    if (interaction > 0.75) {
      return { intent: 'HIGH_INTERACTION', confidence: interaction, responseMode: 'INTERACTIVE' };
    }
    if (attention > 0.70) {
      return { intent: 'ATTENTION_DETECTED', confidence: attention, responseMode: 'GUIDED' };
    }
    if (activity > 0.70) {
      return { intent: 'ACTIVE_MOVEMENT', confidence: activity, responseMode: 'SPATIAL' };
    }
    return {
      intent: 'IDLE',
      confidence: 1 - Math.max(attention, activity, interaction),
      responseMode: 'PASSIVE'
    };
  }
}

// ============================================================
// VolumetricRenderer
// ============================================================
class VolumetricRenderer {
  constructor(resolution = 14) {
    this.resolution = resolution;
  }

  colorForMode(mode) {
    switch (mode) {
      case 'INTERACTIVE': return { r: 0.10, g: 0.90, b: 1.00 }; // cyan brillante
      case 'GUIDED':      return { r: 0.20, g: 0.60, b: 1.00 }; // azul
      case 'SPATIAL':     return { r: 0.50, g: 0.30, b: 1.00 }; // violeta
      default:            return { r: 0.15, g: 0.35, b: 0.55 }; // azul oscuro
    }
  }

  render(state, inference) {
    const points = [];
    const res = this.resolution;
    const attention = state.attention;

    for (let x = 0; x < res; x++) {
      for (let y = 0; y < res; y++) {
        for (let z = 0; z < res; z++) {
          const nx = x / res;
          const ny = y / res;
          const nz = z / res;

          const dx = nx - 0.5;
          const dy = ny - 0.5;
          const dz = nz - 0.5;
          const distance = dx * dx + dy * dy + dz * dz;

          if (distance < 0.13) {
            const intensity = Math.max(0, 1 - distance / 0.13);
            const adaptive = intensity * (0.30 + attention * 0.70);

            points.push({
              x: dx * 2,
              y: dy * 2,
              z: dz * 2,
              intensity: adaptive,
              color: this.colorForMode(inference.responseMode)
            });
          }
        }
      }
    }

    return {
      timestamp: Date.now(),
      points,
      mode: inference.responseMode,
      attention: state.attention,
      interaction: state.interaction
    };
  }
}

// ============================================================
// Pipeline completo
// ============================================================
class VolumetricBiometricAI {
  constructor() {
    this.processor = new BiometricProcessor();
    this.inference = new InferenceEngine();
    this.renderer = new VolumetricRenderer(12);
  }

  process(signals = [], memories = {}) {
    this.processor.clear();
    signals.forEach(s => {
      this.processor.addSignal(s.type, s.confidence, s.features || {});
    });

    const biometricState = this.processor.buildState();
    const inference = this.inference.infer(biometricState);
    const frame = this.renderer.render(biometricState, inference);

    return { biometricState, inference, frame };
  }

  /** Genera señales simuladas suaves (para demo sin sensores reales) */
  simulateSignals(t = 0) {
    return [
      { type: SignalType.FACE_LANDMARKS, confidence: 0.55 + Math.sin(t * 0.7) * 0.25 },
      { type: SignalType.VOICE_FEATURES, confidence: 0.40 + Math.sin(t * 0.5 + 1) * 0.20 },
      { type: SignalType.MOTION, confidence: 0.25 + Math.sin(t * 1.1) * 0.15 },
      { type: SignalType.GESTURE, confidence: 0.20 + Math.sin(t * 0.9 + 2) * 0.18 }
    ];
  }
}

// ============================================================
// HoloScene Renderer (dibuja el VolumetricFrame en canvas 2D)
// ============================================================
class HoloSceneRenderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.animId = null;
    this.t = 0;
    this.ai = new VolumetricBiometricAI();
    this.person = null;
    this.lastFrame = null;
  }

  start(person) {
    this.person = person;
    this.t = 0;
    this.stop();
    this.loop();
  }

  stop() {
    if (this.animId) cancelAnimationFrame(this.animId);
    this.animId = null;
  }

  loop = () => {
    this.t += 0.03;

    // Señales simuladas (más adelante se pueden sustituir por sensores reales)
    const signals = this.ai.simulateSignals(this.t);
    const result = this.ai.process(signals);
    this.lastFrame = result.frame;

    this.draw(result);
    this.animId = requestAnimationFrame(this.loop);
  };

  draw(result) {
    const { ctx, canvas } = this;
    const W = canvas.width;
    const H = canvas.height;
    const frame = result.frame;
    const mode = frame.mode;

    // Fondo
    ctx.fillStyle = '#020617';
    ctx.fillRect(0, 0, W, H);

    // Proyección simple de puntos volumétricos (ortográfica + perspectiva ligera)
    const cx = W / 2;
    const cy = H * 0.42;
    const scale = 110;

    // Ordenar por profundidad (z)
    const sorted = [...frame.points].sort((a, b) => a.z - b.z);

    for (const p of sorted) {
      const perspective = 1 + p.z * 0.35;
      const sx = cx + p.x * scale * perspective;
      const sy = cy - p.y * scale * perspective + p.z * 18;

      const alpha = Math.max(0.05, p.intensity * 0.85);
      const size = 2.2 + p.intensity * 3.5;

      const { r, g, b } = p.color;
      ctx.fillStyle = `rgba(${r * 255 | 0},${g * 255 | 0},${b * 255 | 0},${alpha})`;
      ctx.beginPath();
      ctx.arc(sx, sy, size, 0, Math.PI * 2);
      ctx.fill();
    }

    // Anillo de suelo
    ctx.strokeStyle = mode === 'INTERACTIVE'
      ? 'rgba(56,189,248,0.45)'
      : 'rgba(163,230,53,0.30)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.ellipse(cx, H * 0.78, 82 + Math.sin(this.t) * 3, 15, 0, 0, Math.PI * 2);
    ctx.stroke();

    // Figura de presencia (avatar)
    if (this.person) {
      const gy = H * 0.40 + Math.sin(this.t * 0.8) * 6;
      ctx.font = '68px serif';
      ctx.textAlign = 'center';
      ctx.shadowColor = mode === 'INTERACTIVE'
        ? 'rgba(56,189,248,0.85)'
        : 'rgba(56,189,248,0.55)';
      ctx.shadowBlur = 20 + Math.sin(this.t) * 8;
      ctx.fillStyle = 'rgba(241,245,249,0.92)';
      ctx.fillText(this.person.avatar || '👤', cx, gy);
      ctx.shadowBlur = 0;
    }

    // Escaneo sutil
    ctx.fillStyle = 'rgba(56,189,248,0.02)';
    for (let y = 0; y < H; y += 5) {
      ctx.fillRect(0, y, W, 1);
    }

    // Indicador de modo
    ctx.font = '11px system-ui';
    ctx.fillStyle = 'rgba(148,163,184,0.7)';
    ctx.textAlign = 'center';
    ctx.fillText(mode + ' · atención ' + (frame.attention * 100 | 0) + '%', cx, H - 18);
  }
}

// Exponer
window.SignalType = SignalType;
window.VolumetricBiometricAI = VolumetricBiometricAI;
window.HoloSceneRenderer = HoloSceneRenderer;
