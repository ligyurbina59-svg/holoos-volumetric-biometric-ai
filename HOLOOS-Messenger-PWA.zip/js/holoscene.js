/**
 * XN-Memory · HoloSceneBuilder
 * 5 capas especializadas → Presencia visual de la memoria
 * (Huella biométrica del momento, NO la persona)
 */

// ============================================================
// Pipeline stages (referencia)
// ============================================================
/*
  Señales biométricas (Cámara, Micrófono, IMU)
          ↓
  BiometricProcessor (Agregación + Validación de confianza)
          ↓
  BiometricState (attention, activity, interaction)
          ↓
  InferenceEngine (INTERACTIVE | GUIDED | SPATIAL | PASSIVE)
          ↓
  VolumetricRenderer → VolumetricFrame (4096+ puntos)
          ↓
  HoloSceneBuilder (5 capas)
          ↓
  HoloScene (Mallas + Blend + Cámara)
          ↓
  Canvas 2D / WebGL / OpenGL ES 3.0
          ↓
  ✨ PRESENCIA VISUAL DE LA MEMORIA ✨
*/

// ============================================================
// Capa 1 — AmbientField
// Atmósfera, glow de fondo, ruido de profundidad
// ============================================================
class AmbientFieldLayer {
  constructor() {
    this.time = 0;
  }

  update(dt, frame) {
    this.time += dt;
  }

  draw(ctx, W, H, frame) {
    const mode = frame.mode || 'PASSIVE';

    // Gradiente de atmósfera según modo
    const g = ctx.createRadialGradient(W / 2, H * 0.4, 20, W / 2, H * 0.45, W * 0.7);
    if (mode === 'INTERACTIVE') {
      g.addColorStop(0, 'rgba(56,189,248,0.12)');
      g.addColorStop(0.5, 'rgba(14,165,233,0.04)');
      g.addColorStop(1, 'rgba(2,6,23,0)');
    } else if (mode === 'GUIDED') {
      g.addColorStop(0, 'rgba(59,130,246,0.10)');
      g.addColorStop(1, 'rgba(2,6,23,0)');
    } else if (mode === 'SPATIAL') {
      g.addColorStop(0, 'rgba(139,92,246,0.10)');
      g.addColorStop(1, 'rgba(2,6,23,0)');
    } else {
      g.addColorStop(0, 'rgba(30,58,138,0.08)');
      g.addColorStop(1, 'rgba(2,6,23,0)');
    }
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);

    // Scanlines sutiles
    ctx.fillStyle = 'rgba(56,189,248,0.015)';
    for (let y = 0; y < H; y += 4) {
      ctx.fillRect(0, y + (this.time * 20 % 4), W, 1);
    }
  }
}

// ============================================================
// Capa 2 — VolumeCloud
// Nube de puntos volumétricos (proyección del VolumetricFrame)
// ============================================================
class VolumeCloudLayer {
  constructor() {
    this.points = [];
  }

  update(dt, frame) {
    this.points = frame.points || [];
    this.mode = frame.mode;
    this.attention = frame.attention || 0;
  }

  draw(ctx, W, H, frame) {
    const cx = W / 2;
    const cy = H * 0.40;
    const scale = 105;

    // Ordenar por profundidad
    const sorted = [...this.points].sort((a, b) => a.z - b.z);

    for (const p of sorted) {
      const persp = 1 + p.z * 0.32;
      const sx = cx + p.x * scale * persp;
      const sy = cy - p.y * scale * persp + p.z * 16;

      const alpha = Math.max(0.04, p.intensity * 0.8);
      const size = 1.8 + p.intensity * 3.2;
      const { r, g, b } = p.color;

      ctx.fillStyle = `rgba(${(r * 255) | 0},${(g * 255) | 0},${(b * 255) | 0},${alpha})`;
      ctx.beginPath();
      ctx.arc(sx, sy, size, 0, Math.PI * 2);
      ctx.fill();
    }
  }
}

// ============================================================
// Capa 3 — PresenceCore
// Núcleo de presencia (avatar / silueta simbólica)
// Nunca intenta ser un rostro realista
// ============================================================
class PresenceCoreLayer {
  constructor() {
    this.person = null;
    this.time = 0;
  }

  setPerson(person) {
    this.person = person;
  }

  update(dt) {
    this.time += dt;
  }

  draw(ctx, W, H, frame) {
    if (!this.person) return;

    const cx = W / 2;
    const mode = frame.mode || 'PASSIVE';
    const attention = frame.attention || 0.5;

    // Flotación suave
    const gy = H * 0.38 + Math.sin(this.time * 0.9) * (5 + attention * 4);

    // Glow según modo
    let glow = 'rgba(56,189,248,0.55)';
    if (mode === 'INTERACTIVE') glow = 'rgba(56,189,248,0.9)';
    if (mode === 'SPATIAL') glow = 'rgba(167,139,250,0.75)';

    ctx.font = '70px serif';
    ctx.textAlign = 'center';
    ctx.shadowColor = glow;
    ctx.shadowBlur = 18 + Math.sin(this.time) * 10 + attention * 12;
    ctx.fillStyle = 'rgba(241,245,249,0.93)';
    ctx.fillText(this.person.avatar || '◇', cx, gy);
    ctx.shadowBlur = 0;

    // Anillo de presencia
    ctx.strokeStyle = `rgba(56,189,248,${0.15 + attention * 0.25})`;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(cx, gy - 28, 48 + Math.sin(this.time * 1.2) * 3, 0, Math.PI * 2);
    ctx.stroke();
  }
}

// ============================================================
// Capa 4 — GroundRing + InteractionBeam
// Suelo + haz de interacción
// ============================================================
class InteractionFieldLayer {
  constructor() {
    this.time = 0;
  }

  update(dt) {
    this.time += dt;
  }

  draw(ctx, W, H, frame) {
    const cx = W / 2;
    const mode = frame.mode || 'PASSIVE';
    const interaction = frame.interaction || 0;

    // Haz vertical
    const beam = ctx.createLinearGradient(cx, H * 0.12, cx, H * 0.80);
    beam.addColorStop(0, 'rgba(56,189,248,0)');
    beam.addColorStop(0.4, mode === 'INTERACTIVE'
      ? 'rgba(56,189,248,0.22)'
      : 'rgba(56,189,248,0.10)');
    beam.addColorStop(1, 'rgba(163,230,53,0.04)');

    ctx.fillStyle = beam;
    ctx.beginPath();
    const spread = 18 + interaction * 25;
    ctx.moveTo(cx - 55, H * 0.80);
    ctx.lineTo(cx - spread - Math.sin(this.time) * 4, H * 0.22);
    ctx.lineTo(cx + spread + Math.sin(this.time) * 4, H * 0.22);
    ctx.lineTo(cx + 55, H * 0.80);
    ctx.closePath();
    ctx.fill();

    // Anillo de suelo
    let ringColor = 'rgba(163,230,53,0.30)';
    if (mode === 'INTERACTIVE') ringColor = 'rgba(56,189,248,0.50)';
    if (mode === 'SPATIAL') ringColor = 'rgba(167,139,250,0.40)';

    ctx.strokeStyle = ringColor;
    ctx.lineWidth = 1.5 + interaction * 1.5;
    ctx.beginPath();
    ctx.ellipse(cx, H * 0.80, 78 + Math.sin(this.time) * 4, 14, 0, 0, Math.PI * 2);
    ctx.stroke();

    // Segundo anillo (eco)
    if (interaction > 0.4) {
      ctx.strokeStyle = `rgba(56,189,248,${0.1 + interaction * 0.15})`;
      ctx.beginPath();
      ctx.ellipse(cx, H * 0.80, 95 + Math.sin(this.time * 1.3) * 5, 18, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
  }
}

// ============================================================
// Capa 5 — AuthOverlay + HUD
// Badges de autenticidad + modo + métricas
// ============================================================
class AuthOverlayLayer {
  constructor() {
    this.authLevels = [];
  }

  setAuth(levels) {
    this.authLevels = levels || [];
  }

  draw(ctx, W, H, frame) {
    // Modo + atención
    ctx.font = '11px system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(148,163,184,0.75)';
    const att = ((frame.attention || 0) * 100) | 0;
    const inter = ((frame.interaction || 0) * 100) | 0;
    ctx.fillText(
      `${frame.mode || 'PASSIVE'}  ·  atención ${att}%  ·  interacción ${inter}%`,
      W / 2,
      H - 16
    );

    // Nota filosófica
    ctx.font = '10px system-ui, sans-serif';
    ctx.fillStyle = 'rgba(163,230,53,0.55)';
    ctx.fillText('Huella del momento · no es la persona', W / 2, H - 4);
  }
}

// ============================================================
// HoloSceneBuilder — orquestador de las 5 capas
// ============================================================
class HoloSceneBuilder {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.layers = {
      ambient: new AmbientFieldLayer(),
      volume: new VolumeCloudLayer(),
      presence: new PresenceCoreLayer(),
      interaction: new InteractionFieldLayer(),
      auth: new AuthOverlayLayer()
    };
    this.animId = null;
    this.lastTs = 0;
    this.ai = null; // se inyecta VolumetricBiometricAI
  }

  setAI(ai) {
    this.ai = ai;
  }

  setPerson(person) {
    this.layers.presence.setPerson(person);
  }

  setAuthLevels(levels) {
    this.layers.auth.setAuth(levels);
  }

  start() {
    this.stop();
    this.lastTs = performance.now();
    this.loop(this.lastTs);
  }

  stop() {
    if (this.animId) cancelAnimationFrame(this.animId);
    this.animId = null;
  }

  loop = (ts) => {
    const dt = Math.min(0.05, (ts - this.lastTs) / 1000);
    this.lastTs = ts;

    // Obtener frame del pipeline biométrico
    let frame = { points: [], mode: 'PASSIVE', attention: 0.3, interaction: 0.1 };
    if (this.ai) {
      const signals = this.ai.simulateSignals(ts / 1000);
      const result = this.ai.process(signals);
      frame = result.frame;
    }

    // Actualizar capas
    this.layers.ambient.update(dt, frame);
    this.layers.volume.update(dt, frame);
    this.layers.presence.update(dt);
    this.layers.interaction.update(dt);

    // Dibujar en orden (de atrás a adelante)
    const { ctx, canvas } = this;
    const W = canvas.width;
    const H = canvas.height;

    ctx.fillStyle = '#020617';
    ctx.fillRect(0, 0, W, H);

    this.layers.ambient.draw(ctx, W, H, frame);
    this.layers.interaction.draw(ctx, W, H, frame);   // haz detrás del volumen
    this.layers.volume.draw(ctx, W, H, frame);
    this.layers.presence.draw(ctx, W, H, frame);
    this.layers.auth.draw(ctx, W, H, frame);

    this.animId = requestAnimationFrame(this.loop);
  };
}

window.HoloSceneBuilder = HoloSceneBuilder;
window.AmbientFieldLayer = AmbientFieldLayer;
window.VolumeCloudLayer = VolumeCloudLayer;
window.PresenceCoreLayer = PresenceCoreLayer;
window.InteractionFieldLayer = InteractionFieldLayer;
window.AuthOverlayLayer = AuthOverlayLayer;
