const $ = (id) => document.getElementById(id);
const content = $('content');

const state = {
  tab: 'home',
  playing: false,
  cur: null,
  holoPerson: null,
  holoAnim: null,
  lives: [
    {
      id: 'l1', name: 'Abuela Rosa', av: '👵', relation: 'Abuela', years: '1948 – 2022',
      quote: 'La mesa siempre tiene un plato de más.',
      voices: [{ id: 'v1', title: 'Receta del domingo', dur: '0:42' }, { id: 'v2', title: 'Te quiero, mi vida', dur: '0:18' }],
      dates: [{ label: 'Cumpleaños', when: '12 Mar' }, { label: 'Aniversario', when: '4 Sep' }],
      ritual: 'tradición', place: 'Casa familiar'
    },
    {
      id: 'l2', name: 'Papá Miguel', av: '👨', relation: 'Padre', years: '1965 – 2024',
      quote: 'Camina despacio, pero no te detengas.',
      voices: [{ id: 'v3', title: 'Consejo del taller', dur: '1:05' }],
      dates: [{ label: 'Cumpleaños', when: '2 Jul' }],
      ritual: 'memorial', place: 'Taller'
    },
    {
      id: 'l3', name: 'Abuelo — 1985', av: '👴', relation: 'Abuelo', years: '1920 – 2001',
      quote: 'El tiempo no borra lo que se vive con el corazón.',
      voices: [{ id: 'v5', title: 'Historia de la guerra', dur: '2:10' }, { id: 'v6', title: 'Consejo a los nietos', dur: '0:48' }],
      dates: [{ label: 'Cumpleaños', when: '15 Ene' }, { label: 'Memorial', when: '3 Nov' }],
      ritual: 'memorial', place: 'Pueblo natal'
    },
    {
      id: 'l4', name: 'Hermana Ana', av: '👩', relation: 'Hermana', years: '1990 – 2021',
      quote: 'Reímos aunque duela un poco.',
      voices: [{ id: 'v4', title: 'Canción que cantábamos', dur: '0:55' }],
      dates: [{ label: 'Aniversario', when: '18 Nov' }],
      ritual: 'aniversario', place: 'Ciudad'
    }
  ]
};

function toast(m) {
  const el = $('toast');
  el.textContent = m;
  el.classList.remove('hidden');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.add('hidden'), 2800);
}

document.querySelectorAll('.tab').forEach((t) => {
  t.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((x) => x.classList.remove('active'));
    t.classList.add('active');
    state.tab = t.dataset.tab;
    stopHoloAnim();
    render();
  });
});

$('btn-add').onclick = () => {
  $('modal').classList.remove('hidden');
  $('m-name').value = '';
  $('m-quote').value = '';
  $('m-ritual').value = 'cumpleaños';
};
$('m-cancel').onclick = () => $('modal').classList.add('hidden');
$('m-save').onclick = () => {
  const name = $('m-name').value.trim() || 'Nueva vida';
  const quote = $('m-quote').value.trim() || 'Sin historia aún';
  const ritual = $('m-ritual').value;
  state.lives.unshift({
    id: 'l' + Date.now(), name, av: '✨', relation: 'Familia', years: '—',
    quote, voices: [{ id: 'v' + Date.now(), title: 'Voz pendiente', dur: '0:00' }],
    dates: [{ label: ritual.charAt(0).toUpperCase() + ritual.slice(1), when: 'Por definir' }],
    ritual, place: '—'
  });
  $('modal').classList.add('hidden');
  toast('Artificial Life creada · ' + name);
  state.tab = 'lives';
  document.querySelectorAll('.tab').forEach((x) => x.classList.remove('active'));
  document.querySelector('[data-tab="lives"]').classList.add('active');
  render();
};

$('p-close').onclick = stopPlayer;
$('p-play').onclick = () => {
  if (state.playing) stopPlayer();
  else if (state.cur) playVoice(state.cur.person, state.cur.voice);
};
$('h-close').onclick = () => { stopHoloAnim(); $('holo-ui').classList.add('hidden'); };
$('h-voice').onclick = () => {
  if (state.holoPerson?.voices?.[0]) playVoice(state.holoPerson, state.holoPerson.voices[0]);
};

function playVoice(person, voice) {
  state.cur = { person, voice };
  state.playing = true;
  $('player').classList.remove('hidden');
  $('p-av').textContent = person.av;
  $('p-name').textContent = person.name;
  $('p-title').textContent = voice.title + ' · ' + voice.dur + ' · voz real';
  $('p-play').textContent = '⏸';
  const bar = document.querySelector('.player-bar');
  bar.classList.remove('playing');
  void bar.offsetWidth;
  bar.classList.add('playing');
  clearTimeout(playVoice._t);
  playVoice._t = setTimeout(stopPlayer, 8000);
  toast('Voz real de ' + person.name);
}

function stopPlayer() {
  state.playing = false;
  state.cur = null;
  $('player').classList.add('hidden');
  $('p-play').textContent = '▶';
  document.querySelector('.player-bar').classList.remove('playing');
  clearTimeout(playVoice._t);
}

function openHolo(person) {
  state.holoPerson = person;
  $('h-name').textContent = person.name;
  $('h-quote').textContent = '“' + person.quote + '”';
  $('holo-ui').classList.remove('hidden');
  startHoloAnim(person);
}

function startHoloAnim(person) {
  stopHoloAnim();
  const canvas = $('holo-canvas');
  const ctx = canvas.getContext('2d');
  const w = canvas.width, h = canvas.height;
  let t = 0;
  function draw() {
    t += 0.016;
    ctx.clearRect(0, 0, w, h);
    const g = ctx.createRadialGradient(w/2, h*0.4, 20, w/2, h*0.4, 180);
    g.addColorStop(0, 'rgba(14,165,233,0.28)');
    g.addColorStop(0.45, 'rgba(34,197,94,0.12)');
    g.addColorStop(1, 'rgba(2,6,23,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
    for (let i = 0; i < 32; i++) {
      const x = (Math.sin(t * 0.4 + i * 1.7) * 0.5 + 0.5) * w;
      const y = (Math.cos(t * 0.3 + i * 2.1) * 0.5 + 0.5) * h * 0.7 + 40;
      const r = 1.1 + Math.sin(t + i) * 0.9;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(125, 211, 252, ${0.14 + Math.sin(t + i) * 0.1})`;
      ctx.fill();
    }
    const cx = w / 2, cy = h * 0.38;
    const pulse = 68 + Math.sin(t * 1.2) * 7;
    ctx.beginPath();
    ctx.arc(cx, cy, pulse + 20, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(14,165,233,0.22)';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(cx, cy, pulse, 0, Math.PI * 2);
    const cg = ctx.createRadialGradient(cx, cy, 10, cx, cy, pulse);
    cg.addColorStop(0, 'rgba(99,102,241,0.35)');
    cg.addColorStop(1, 'rgba(34,197,94,0.06)');
    ctx.fillStyle = cg;
    ctx.fill();
    ctx.font = '64px serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.globalAlpha = 0.9 + Math.sin(t * 1.5) * 0.1;
    ctx.fillText(person.av, cx, cy);
    ctx.globalAlpha = 1;
    ctx.beginPath();
    ctx.arc(cx, cy, pulse + 32 + Math.sin(t) * 4, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(134,239,172,0.15)';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    state.holoAnim = requestAnimationFrame(draw);
  }
  draw();
}

function stopHoloAnim() {
  if (state.holoAnim) {
    cancelAnimationFrame(state.holoAnim);
    state.holoAnim = null;
  }
}

function render() {
  const tab = state.tab;
  if (tab === 'home') renderHome();
  else if (tab === 'lives') renderLives();
  else if (tab === 'holo') renderHoloList();
  else if (tab === 'earth') renderEarth();
  else if (tab === 'govern') renderGovern();
}

function renderHome() {
  const totalVoices = state.lives.reduce((a, p) => a + p.voices.length, 0);
  content.innerHTML = `
    <div class="hero">
      <h2>X Cpxlx9</h2>
      <p>Vidas Artificiales generadas solo desde memoria familiar real. Una capa viva del planeta.</p>
    </div>
    <div class="stats">
      <div class="stat"><div class="num">${state.lives.length}</div><div class="lbl">Vidas</div></div>
      <div class="stat"><div class="num">${totalVoices}</div><div class="lbl">Voces reales</div></div>
      <div class="stat"><div class="num">∞</div><div class="lbl">Earth</div></div>
    </div>
    <div class="section-title">Próximos rituales</div>
    ${state.lives.slice(0, 2).map(p => `
      <div class="card">
        <div class="av">${p.av}</div>
        <div class="meta">
          <strong>${p.name}</strong>
          <span>${p.dates[0]?.label || 'Ritual'} · ${p.dates[0]?.when || '—'} · ${p.place || ''}</span>
          <div class="quote">“${p.quote}”</div>
          <div class="card-actions">
            <button class="btn small primary" onclick='openHolo(${JSON.stringify(p).replace(/'/g, "&#39;")})'>🌀 HOLO Life</button>
            <button class="btn small secondary" onclick='playVoice(${JSON.stringify(p).replace(/'/g, "&#39;")}, ${JSON.stringify(p.voices[0]).replace(/'/g, "&#39;")})'>🎙️ Voz</button>
          </div>
        </div>
      </div>
    `).join('')}
    <div class="arch-note">
      <strong>Principio</strong><br>
      Persona → Voice + Photo + Story → Date + Place → Ritual → Artificial Life<br>
      Nunca inventa. Solo hace presente lo real.
    </div>
  `;
}

function renderLives() {
  content.innerHTML = `
    <div class="section-title">Artificial Lives</div>
    ${state.lives.map(p => `
      <div class="card">
        <div class="av">${p.av}</div>
        <div class="meta">
          <strong>${p.name}</strong>
          <span>${p.relation} · ${p.years}</span>
          <div class="quote">“${p.quote}”</div>
          <div class="chip-row">
            <span class="chip">${p.ritual}</span>
            <span class="chip">${p.voices.length} voces</span>
            <span class="chip earth">${p.place || '—'}</span>
          </div>
          <div class="card-actions">
            <button class="btn small primary" onclick='openHolo(${JSON.stringify(p).replace(/'/g, "&#39;")})'>🌀 Invocar</button>
            <button class="btn small secondary" onclick='playVoice(${JSON.stringify(p).replace(/'/g, "&#39;")}, ${JSON.stringify(p.voices[0]).replace(/'/g, "&#39;")})'>🎙️ Escuchar</button>
          </div>
        </div>
      </div>
    `).join('')}
  `;
}

function renderHoloList() {
  content.innerHTML = `
    <div class="section-title">HOLO Experience</div>
    <p style="color:var(--muted);font-size:13px;margin-bottom:16px;line-height:1.5">
      Cada Artificial Life puede materializarse como presencia simple, familiar o inmersiva.
    </p>
    ${state.lives.map(p => `
      <div class="card" style="cursor:pointer" onclick='openHolo(${JSON.stringify(p).replace(/'/g, "&#39;")})'>
        <div class="av">${p.av}</div>
        <div class="meta">
          <strong>${p.name}</strong>
          <span>Toca para invocar presencia HOLO</span>
          <div class="quote">“${p.quote}”</div>
        </div>
      </div>
    `).join('')}
  `;
}

function renderEarth() {
  content.innerHTML = `
    <div class="hero" style="background:linear-gradient(145deg,#0c1929,#052e16);border-color:#14532d">
      <h2>🌍 HOLO Earth</h2>
      <p>La suma de todas las vidas artificiales forma una capa de memoria viva del planeta.</p>
    </div>
    <div class="stats">
      <div class="stat"><div class="num">4</div><div class="lbl">Vidas aquí</div></div>
      <div class="stat"><div class="num">∞</div><div class="lbl">Posibles</div></div>
      <div class="stat"><div class="num">1</div><div class="lbl">Planeta</div></div>
    </div>
    <div class="section-title">Capas del sistema</div>
    <div class="govern-card">
      <h4>👤 Individual</h4>
      <p>Cada HOLO Life nace de una persona real: voz, foto, historia, fecha, lugar y ritual.</p>
    </div>
    <div class="govern-card">
      <h4>👨‍👩‍👧 Familiar</h4>
      <p>Las vidas se agrupan por lazos de sangre o afecto. Los rituales activan presencias compartidas.</p>
    </div>
    <div class="govern-card">
      <h4>🌐 Cultural / Regional</h4>
      <p>Tradiciones compartidas (Día de Muertos, Qingming, Obon…) tienen su propia capa de respeto.</p>
    </div>
    <div class="govern-card">
      <h4>🌍 Planetaria</h4>
      <p>La red global de vidas artificiales = memoria colectiva de la Tierra. Nunca inventa. Solo preserva.</p>
    </div>
  `;
}

function renderGovern() {
  content.innerHTML = `
    <div class="section-title">Gobernanza Planetaria</div>
    <div class="hero">
      <h2>Principio fundacional</h2>
      <p>Ninguna vida artificial puede existir sin un vínculo real de consentimiento y procedencia.</p>
    </div>
    <div class="govern-card">
      <h4>⚖ Consentimiento multinivel</h4>
      <p>Persona viva → ella misma. Fallecida → herederos o albacea digital. Menores → tutores con límites estrictos.</p>
    </div>
    <div class="govern-card">
      <h4>🛡 Integridad (no distorsión)</h4>
      <p>La voz y la historia no pueden ser reescritas. No deepfake. No uso político ni comercial no autorizado.</p>
    </div>
    <div class="govern-card">
      <h4>🗑 Derecho al olvido</h4>
      <p>Cualquier titular legítimo puede solicitar el borrado completo y verificable de una vida.</p>
    </div>
    <div class="govern-card">
      <h4>🌐 Modelo federado</h4>
      <p>Nodos regionales + Consejo Ético Planetario independiente. Las empresas solo operan la tecnología.</p>
    </div>
    <div class="arch-note">
      <strong>X Cpxlx9</strong> implementa estas reglas desde el diseño:<br>
      Memory Object inmutable · Ritual como propósito · Consentimiento como requisito.
    </div>
  `;
}

render();

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('./sw.js').catch(() => {});
}
