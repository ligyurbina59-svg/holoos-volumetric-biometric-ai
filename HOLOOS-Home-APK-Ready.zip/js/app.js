// HOLOOS Home — Core Application
const modules = {
  memory: {
    title: "Memory Graph",
    content: `
      <h3>🧠 Memory Graph</h3>
      <p>Preserva y conecta memorias personales y compartidas. Visualiza relaciones entre eventos, personas y lugares.</p>
      <p>HOLO no devuelve vidas. Preserva memorias.</p>
      <button class="action-btn" onclick="alert('Módulo Memory Graph — próximamente')">Abrir Memory Graph</button>
    `
  },
  ai: {
    title: "AI Assistant",
    content: `
      <h3>🤖 AI Assistant</h3>
      <p>Asistente técnico e inteligente integrado en el núcleo HOLOOS. Puede ayudarte con movilidad, mensajería y análisis de datos.</p>
      <button class="action-btn" onclick="alert('Asistente IA activado (simulación)')">Hablar con AI</button>
    `
  },
  mobility: {
    title: "MobilityOS",
    content: `
      <h3>🚗 MobilityOS</h3>
      <p>Viaje, Comida y Entrega con asignación inteligente de vehículos y mapa en tiempo real.</p>
      <p>Continúa desde la versión anterior de HOLOOS MobilityOS.</p>
      <button class="action-btn" onclick="alert('Abriendo MobilityOS...')">Abrir MobilityOS</button>
    `
  },
  messenger: {
    title: "Messenger",
    content: `
      <h3>💬 HOLOOS Messenger</h3>
      <p>Mensajería con presencia holográfica conceptual. Chats, contactos y memoria compartida.</p>
      <button class="action-btn" onclick="alert('Abriendo Messenger...')">Abrir Messenger</button>
    `
  },
  bio: {
    title: "Bio Engine",
    content: `
      <h3>🧬 Bio Engine</h3>
      <p>Fusión de sensores biométricos y percepción del entorno. Preparado para futuras integraciones de salud y presencia.</p>
      <button class="action-btn" onclick="alert('Bio Engine — módulo experimental')">Activar Bio Engine</button>
    `
  },
  spatial: {
    title: "Spatial XR",
    content: `
      <h3>🌐 Spatial XR</h3>
      <p>Runtime espacial para AR, VR y Mixed Reality. Base para experiencias volumétricas y proyección holográfica.</p>
      <button class="action-btn" onclick="alert('Spatial XR — en desarrollo')">Entrar a Spatial</button>
    `
  }
};

document.querySelectorAll('.module').forEach(btn => {
  btn.addEventListener('click', () => {
    const key = btn.dataset.module;
    const mod = modules[key];
    if (!mod) return;

    document.getElementById('panel-title').textContent = mod.title;
    document.getElementById('panel-content').innerHTML = mod.content;
    document.getElementById('panel').classList.remove('hidden');
  });
});

document.getElementById('panel-close').addEventListener('click', () => {
  document.getElementById('panel').classList.add('hidden');
});

// Bottom navigation
document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
    item.classList.add('active');

    const tab = item.dataset.tab;
    if (tab === 'memory') {
      document.querySelector('[data-module="memory"]').click();
    } else if (tab === 'ai') {
      document.querySelector('[data-module="ai"]').click();
    } else if (tab === 'more') {
      alert('Más opciones próximamente');
    }
  });
});

// AI button
document.getElementById('btn-ai').addEventListener('click', () => {
  document.querySelector('[data-module="ai"]').click();
});

// Service Worker
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('./sw.js').catch(() => {});
}

console.log('HOLOOS Home loaded');
