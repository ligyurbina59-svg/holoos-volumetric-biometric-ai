# HOLOOS Home

**Continuación del ecosistema HOLOOS**

Centro holográfico principal que unifica:

- 🧠 Memory Graph
- 🤖 AI Assistant
- 🚗 MobilityOS
- 💬 Messenger
- 🧬 Bio Engine
- 🌐 Spatial XR

## Características

- Interfaz oscura tipo “Holographic Home”
- Módulos interconectados
- Progressive Web App (instalable)
- Service Worker + offline básico
- Diseño mobile-first

## Ejecutar

```bash
npx serve .
# o
python -m http.server 8080
```

## Estructura

```
holoos_home/
├── index.html
├── css/app.css
├── js/app.js
├── icons/
├── manifest.json
├── sw.js
├── LICENSE
└── README.md
```

## Licencia

MIT License — Software libre y open source.

## Relación con el ecosistema

Esta app es la **continuación** de:

- HOLOOS MobilityOS
- HOLOOS Messenger

Sirve como hub central del sistema HOLOOS.
