// TerraOS - Core interaction
document.addEventListener('DOMContentLoaded', () => {
  // Register Service Worker
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js')
      .then(() => console.log('TerraOS SW registered'))
      .catch(err => console.warn('SW registration failed', err));
  }

  // Join button
  const joinBtn = document.getElementById('joinBtn');
  if (joinBtn) {
    joinBtn.addEventListener('click', () => {
      const msg = `🌍 Gracias por unirte a TerraOS.\n\nEste es solo el comienzo.\n\nLa verdadera tecnología para el planeta se construye en comunidad: código abierto, sensores abiertos, datos abiertos e impacto medible.\n\nPróximos pasos:\n• Contribuye ideas\n• Conecta sensores locales\n• Propón módulos regenerativos\n\nEl planeta no necesita más apps.\nNecesita sistemas que regeneren.`;
      alert(msg);
      
      // Visual feedback
      joinBtn.textContent = '✓ Estás dentro';
      joinBtn.style.background = 'linear-gradient(135deg, #22c55e, #16a34a)';
      joinBtn.disabled = true;
    });
  }

  // Simple status pulse for the globe
  const globe = document.querySelector('.globe');
  if (globe) {
    setInterval(() => {
      globe.style.transform = `scale(${1 + Math.random() * 0.02})`;
      setTimeout(() => {
        globe.style.transform = 'scale(1)';
      }, 300);
    }, 5000);
  }

  // Log planetary intent
  console.log('%cTerraOS', 'font-size: 24px; font-weight: bold; color: #39FF14;');
  console.log('%cTecnología regenerativa para el Planeta Tierra', 'color: #00D4FF;');
  console.log('Más allá de apps, juegos y software extractivo.');
});
